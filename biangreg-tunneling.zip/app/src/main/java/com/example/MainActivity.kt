package com.example

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.TunnelProfile
import com.example.data.model.VpnConnectionState
import com.example.ui.MainViewModel
import com.example.ui.components.DnsSettingsDialog
import com.example.ui.components.ExportConfigDialog
import com.example.ui.components.ImportTextDialog
import com.example.ui.components.PayloadGeneratorDialog
import com.example.ui.screens.ConfigManagerScreen
import com.example.ui.screens.LogTerminalScreen
import com.example.ui.screens.PayloadEditorScreen
import com.example.ui.screens.TunnelDashboardScreen
import com.example.ui.theme.BianGregTunnelingTheme
import kotlinx.serialization.Serializable

@Serializable
sealed interface AppRoute {
    @Serializable
    data object Tunnel : AppRoute

    @Serializable
    data object Editor : AppRoute

    @Serializable
    data object Configs : AppRoute

    @Serializable
    data object Logs : AppRoute
}

private data class NavTab(
    val route: AppRoute,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: MainViewModel = viewModel()
            val settings by vm.settings.collectAsStateWithLifecycle()
            BianGregTunnelingTheme(darkTheme = settings.darkTheme) {
                BianGregTunnelingApp(viewModel = vm)
            }
        }
    }
}

@Composable
fun BianGregTunnelingApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val logs by viewModel.logs.collectAsStateWithLifecycle()
    val draft by viewModel.editorDraft.collectAsStateWithLifecycle()
    val isProbing by viewModel.isProbing.collectAsStateWithLifecycle()
    val handshakeResult by viewModel.handshakeResult.collectAsStateWithLifecycle()
    val configFilter by viewModel.configFilter.collectAsStateWithLifecycle()

    var showPayloadGenDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showDnsDialog by remember { mutableStateOf(false) }
    var exportTargets by remember { mutableStateOf<List<TunnelProfile>?>(null) }

    LaunchedEffect(Unit) {
        viewModel.uiMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            viewModel.connectActiveProfile()
        } else {
            viewModel.emitMessage(context.getString(R.string.vpn_permission_required))
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        val vpnIntent = VpnService.prepare(context)
        if (vpnIntent != null) {
            vpnPermissionLauncher.launch(vpnIntent)
        } else {
            viewModel.connectActiveProfile()
        }
    }

    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.importFromUri(context.contentResolver, it) }
    }

    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        uri?.let { viewModel.writePendingExportToUri(context.contentResolver, it) }
    }

    fun requestStartVpn() {
        val status = telemetry.status
        if (status == VpnConnectionState.CONNECTED ||
            status == VpnConnectionState.CONNECTING ||
            status == VpnConnectionState.DISCONNECTING
        ) {
            viewModel.disconnectVpn()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        val vpnIntent = VpnService.prepare(context)
        if (vpnIntent != null) {
            vpnPermissionLauncher.launch(vpnIntent)
        } else {
            viewModel.connectActiveProfile()
        }
    }

    fun navigateTo(route: AppRoute) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val tabs = remember {
        listOf(
            NavTab(AppRoute.Tunnel, "Tunnel", Icons.Rounded.Shield, "nav_tunnel"),
            NavTab(AppRoute.Editor, "Payload", Icons.Rounded.Tune, "nav_editor"),
            NavTab(AppRoute.Configs, "Config", Icons.Rounded.Folder, "nav_configs"),
            NavTab(AppRoute.Logs, "Log", Icons.Rounded.Terminal, "nav_logs")
        )
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar {
                        tabs.forEach { tab ->
                            val selected = currentDest?.hasRoute(tab.route::class) == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail {
                        tabs.forEach { tab ->
                            val selected = currentDest?.hasRoute(tab.route::class) == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = AppRoute.Tunnel,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<AppRoute.Tunnel> {
                        TunnelDashboardScreen(
                            telemetry = telemetry,
                            activeProfile = activeProfile,
                            settings = settings,
                            isProbing = isProbing,
                            onToggleConnection = { requestStartVpn() },
                            onProbeLatency = { viewModel.probeActiveProfileLatency() },
                            onOpenEditor = {
                                activeProfile?.let { viewModel.loadProfileToEditor(it) }
                                navigateTo(AppRoute.Editor)
                            },
                            onOpenConfigs = { navigateTo(AppRoute.Configs) },
                            onOpenImport = { showImportDialog = true },
                            onOpenExport = {
                                if (profiles.isEmpty()) {
                                    viewModel.emitMessage("Belum ada config untuk diekspor.")
                                } else {
                                    exportTargets = activeProfile?.let { listOf(it) } ?: profiles
                                }
                            },
                            onOpenDnsSettings = { showDnsDialog = true }
                        )
                    }

                    composable<AppRoute.Editor> {
                        PayloadEditorScreen(
                            draft = draft,
                            isProbing = isProbing,
                            handshakeResult = handshakeResult,
                            onUpdateDraft = { viewModel.updateDraft(it) },
                            onNewDraft = { viewModel.startNewDraft(it) },
                            onOpenPayloadGenerator = { showPayloadGenDialog = true },
                            onAppendTag = { viewModel.appendPayloadTag(it) },
                            onOpenImportPaste = { showImportDialog = true },
                            onTestHandshake = { viewModel.testDraftHandshake() },
                            onSaveProfile = { viewModel.saveEditorDraft(activateAfterSave = true) }
                        )
                    }

                    composable<AppRoute.Configs> {
                        ConfigManagerScreen(
                            profiles = profiles,
                            activeProfileId = activeProfile?.id,
                            filter = configFilter,
                            onFilterChange = { viewModel.setConfigFilter(it) },
                            onSelectProfile = { viewModel.selectActiveProfile(it) },
                            onEditProfile = {
                                viewModel.loadProfileToEditor(it)
                                navigateTo(AppRoute.Editor)
                            },
                            onDeleteProfile = { viewModel.deleteProfile(it) },
                            onCreateNew = {
                                viewModel.startNewDraft()
                                navigateTo(AppRoute.Editor)
                            },
                            onImportFile = {
                                importFileLauncher.launch(arrayOf("*/*"))
                            },
                            onImportText = { showImportDialog = true },
                            onExportAll = { exportTargets = profiles },
                            onExportSingle = { exportTargets = listOf(it) },
                            onCopyShareUri = { profile ->
                                val uri = viewModel.exportShareUri(profile)
                                copyToClipboard(context, "BianGreg Config", uri)
                                viewModel.emitMessage("Link config disalin ke clipboard.")
                            },
                            onShareUri = { profile ->
                                val uri = viewModel.exportShareUri(profile)
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, uri)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Bagikan Config"))
                            }
                        )
                    }

                    composable<AppRoute.Logs> {
                        LogTerminalScreen(
                            logs = logs,
                            onCopyAllLogs = { text ->
                                copyToClipboard(context, "BianGreg Logs", text)
                                viewModel.emitMessage("Log disalin ke clipboard.")
                            },
                            onClearLogs = { viewModel.clearLogs() }
                        )
                    }
                }
            }
        }
    }

    if (showPayloadGenDialog) {
        PayloadGeneratorDialog(
            initialBugHost = draft.sniHost.ifBlank { draft.proxyHost },
            onDismiss = { showPayloadGenDialog = false },
            onGenerate = { options -> viewModel.applyGeneratedPayload(options) }
        )
    }

    if (showImportDialog) {
        ImportTextDialog(
            onDismiss = { showImportDialog = false },
            onImport = { text -> viewModel.importConfigText(text, loadIntoEditor = true) },
            onPickFile = { importFileLauncher.launch(arrayOf("*/*")) }
        )
    }

    exportTargets?.let { targets ->
        ExportConfigDialog(
            title = if (targets.size == 1) "Ekspor ${targets.first().name}" else "Ekspor ${targets.size} Config",
            profileCount = targets.size,
            onDismiss = { exportTargets = null },
            onExportFile = { lock ->
                viewModel.prepareExportBundle(targets, lock)
                val ext = if (lock) "bgt" else "json"
                val base = if (targets.size == 1) {
                    targets.first().name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                } else {
                    "biangreg_configs"
                }
                exportFileLauncher.launch("$base.$ext")
            },
            onCopyText = { lock ->
                val text = viewModel.prepareExportBundle(targets, lock)
                copyToClipboard(context, "BianGreg Bundle", text)
                viewModel.emitMessage("Teks config berhasil disalin.")
            }
        )
    }

    if (showDnsDialog) {
        DnsSettingsDialog(
            currentPrimary = settings.dnsPrimary,
            currentSecondary = settings.dnsSecondary,
            wakeLockEnabled = settings.wakeLockEnabled,
            autoReconnect = settings.autoReconnect,
            darkTheme = settings.darkTheme,
            onDismiss = { showDnsDialog = false },
            onSaveDns = { p, s -> viewModel.updateDns(p, s) },
            onWakeLockChange = { viewModel.setWakeLock(it) },
            onAutoReconnectChange = { viewModel.setAutoReconnect(it) },
            onDarkThemeChange = { viewModel.setDarkTheme(it) }
        )
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    cb.setPrimaryClip(ClipData.newPlainText(label, text))
}
