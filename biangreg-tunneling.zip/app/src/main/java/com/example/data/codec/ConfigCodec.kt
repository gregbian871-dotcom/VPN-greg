package com.example.data.codec

import android.util.Base64
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.model.V2RaySecurity
import com.example.data.model.V2RayTransport
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.UUID

@Serializable
data class BianGregConfigBundle(
    val version: Int = 1,
    val app: String = "BianGreg Tunneling",
    val locked: Boolean = false,
    val exportedAt: Long = System.currentTimeMillis(),
    val profiles: List<TunnelProfile> = emptyList()
)

data class ConfigImportResult(
    val profiles: List<TunnelProfile>,
    val warnings: List<String> = emptyList()
)

object ConfigCodec {

    private const val BGT_PREFIX = "BGT1:"

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun exportBundle(profiles: List<TunnelProfile>, lockCredentials: Boolean): String {
        val processed = if (lockCredentials) {
            profiles.map { it.copy(isLocked = true) }
        } else {
            profiles
        }
        val bundle = BianGregConfigBundle(
            version = 1,
            app = "BianGreg Tunneling",
            locked = lockCredentials,
            exportedAt = System.currentTimeMillis(),
            profiles = processed
        )
        val rawJson = json.encodeToString(BianGregConfigBundle.serializer(), bundle)
        return if (lockCredentials) {
            val encoded = Base64.encodeToString(rawJson.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            "$BGT_PREFIX$encoded"
        } else {
            rawJson
        }
    }

    fun exportShareUri(profile: TunnelProfile): String {
        val tag = urlEncode(profile.name.ifBlank { "BianGreg" })
        return when (profile.protocol) {
            TunnelProtocol.V2RAY_VMESS -> {
                val obj = buildString {
                    append("{")
                    append("\"v\":\"2\",")
                    append("\"ps\":\"${escapeJson(profile.name)}\",")
                    append("\"add\":\"${escapeJson(profile.v2rayAddress)}\",")
                    append("\"port\":\"${profile.v2rayPort}\",")
                    append("\"id\":\"${escapeJson(profile.v2rayUuid)}\",")
                    append("\"aid\":\"${profile.v2rayAlterId}\",")
                    append("\"scy\":\"${escapeJson(profile.v2raySecurityMethod)}\",")
                    append("\"net\":\"${profile.v2rayTransport.wireValue}\",")
                    append("\"type\":\"none\",")
                    append("\"host\":\"${escapeJson(profile.v2rayWsHost)}\",")
                    append("\"path\":\"${escapeJson(profile.v2rayWsPath)}\",")
                    append("\"tls\":\"${if (profile.v2raySecurity == V2RaySecurity.TLS) "tls" else ""}\",")
                    append("\"sni\":\"${escapeJson(profile.v2raySni)}\",")
                    append("\"fp\":\"${escapeJson(profile.v2rayFingerprint)}\"")
                    append("}")
                }
                "vmess://${Base64.encodeToString(obj.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)}"
            }

            TunnelProtocol.V2RAY_VLESS -> {
                val params = mutableListOf(
                    "type=${profile.v2rayTransport.wireValue}",
                    "security=${profile.v2raySecurity.wireValue}"
                )
                if (profile.v2raySni.isNotBlank()) params += "sni=${urlEncode(profile.v2raySni)}"
                if (profile.v2rayWsHost.isNotBlank()) params += "host=${urlEncode(profile.v2rayWsHost)}"
                if (profile.v2rayWsPath.isNotBlank()) params += "path=${urlEncode(profile.v2rayWsPath)}"
                if (profile.v2rayFingerprint.isNotBlank()) params += "fp=${urlEncode(profile.v2rayFingerprint)}"
                if (profile.v2rayPublicKey.isNotBlank()) params += "pbk=${urlEncode(profile.v2rayPublicKey)}"
                if (profile.v2rayShortId.isNotBlank()) params += "sid=${urlEncode(profile.v2rayShortId)}"
                "vless://${profile.v2rayUuid}@${profile.v2rayAddress}:${profile.v2rayPort}?${params.joinToString("&")}#$tag"
            }

            TunnelProtocol.V2RAY_TROJAN -> {
                val params = mutableListOf(
                    "type=${profile.v2rayTransport.wireValue}",
                    "security=${profile.v2raySecurity.wireValue}"
                )
                if (profile.v2raySni.isNotBlank()) params += "sni=${urlEncode(profile.v2raySni)}"
                if (profile.v2rayWsHost.isNotBlank()) params += "host=${urlEncode(profile.v2rayWsHost)}"
                if (profile.v2rayWsPath.isNotBlank()) params += "path=${urlEncode(profile.v2rayWsPath)}"
                "trojan://${urlEncode(profile.v2rayUuid)}@${profile.v2rayAddress}:${profile.v2rayPort}?${params.joinToString("&")}#$tag"
            }

            TunnelProtocol.V2RAY_SHADOWSOCKS -> {
                val method = profile.v2raySecurityMethod.ifBlank { "aes-256-gcm" }
                val cred = Base64.encodeToString(
                    "$method:${profile.v2rayUuid}".toByteArray(Charsets.UTF_8),
                    Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING
                )
                "ss://$cred@${profile.v2rayAddress}:${profile.v2rayPort}#$tag"
            }

            TunnelProtocol.SSH_DIRECT,
            TunnelProtocol.SSH_PAYLOAD,
            TunnelProtocol.SSH_SSL_SNI,
            TunnelProtocol.SSH_WEBSOCKET -> {
                val params = mutableListOf("mode=${profile.protocol.name}")
                if (profile.proxyHost.isNotBlank()) {
                    params += "proxy=${urlEncode("${profile.proxyHost}:${profile.proxyPort}")}"
                }
                if (profile.sniHost.isNotBlank()) params += "sni=${urlEncode(profile.sniHost)}"
                if (profile.payload.isNotBlank()) params += "payload=${urlEncode(profile.payload)}"
                val userPart = if (profile.sshPassword.isNotBlank()) {
                    "${urlEncode(profile.sshUsername)}:${urlEncode(profile.sshPassword)}"
                } else {
                    urlEncode(profile.sshUsername)
                }
                "ssh://$userPart@${profile.sshHost}:${profile.sshPort}?${params.joinToString("&")}#$tag"
            }
        }
    }

    fun importAny(rawInput: String): ConfigImportResult {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return ConfigImportResult(emptyList(), listOf("Teks atau file konfigurasi kosong."))
        }

        // 1. BGT1 locked/portable container
        if (trimmed.startsWith(BGT_PREFIX)) {
            return runCatching {
                val b64 = trimmed.removePrefix(BGT_PREFIX).trim()
                val decoded = String(decodeBase64Flexible(b64), Charsets.UTF_8)
                parseJsonContainer(decoded)
            }.getOrElse {
                ConfigImportResult(emptyList(), listOf("Gagal mendekode file .bgt: ${it.message}"))
            }
        }

        // 2. Plain JSON bundle or single TunnelProfile JSON
        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            return parseJsonContainer(trimmed)
        }

        // 3. Multi-line URI list (vmess://, vless://, trojan://, ss://, ssh://)
        val profiles = mutableListOf<TunnelProfile>()
        val warnings = mutableListOf<String>()
        val lines = trimmed.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        for ((index, line) in lines.withIndex()) {
            when {
                line.startsWith("vmess://", ignoreCase = true) -> {
                    parseVmessUri(line)?.let(profiles::add)
                        ?: warnings.add("Baris ${index + 1}: format vmess:// tidak valid.")
                }

                line.startsWith("vless://", ignoreCase = true) -> {
                    parseVlessOrTrojanUri(line, isTrojan = false)?.let(profiles::add)
                        ?: warnings.add("Baris ${index + 1}: format vless:// tidak valid.")
                }

                line.startsWith("trojan://", ignoreCase = true) -> {
                    parseVlessOrTrojanUri(line, isTrojan = true)?.let(profiles::add)
                        ?: warnings.add("Baris ${index + 1}: format trojan:// tidak valid.")
                }

                line.startsWith("ss://", ignoreCase = true) -> {
                    parseShadowsocksUri(line)?.let(profiles::add)
                        ?: warnings.add("Baris ${index + 1}: format ss:// tidak valid.")
                }

                line.startsWith("ssh://", ignoreCase = true) -> {
                    parseSshUri(line)?.let(profiles::add)
                        ?: warnings.add("Baris ${index + 1}: format ssh:// tidak valid.")
                }

                line.startsWith(BGT_PREFIX) -> {
                    val sub = importAny(line)
                    profiles.addAll(sub.profiles)
                    warnings.addAll(sub.warnings)
                }

                else -> warnings.add("Baris ${index + 1}: skema tidak dikenali.")
            }
        }
        return ConfigImportResult(profiles, warnings)
    }

    private fun parseJsonContainer(rawJson: String): ConfigImportResult {
        return runCatching {
            when {
                rawJson.trimStart().startsWith("[") -> {
                    val list = json.decodeFromString<List<TunnelProfile>>(rawJson)
                    ConfigImportResult(list.map { it.copy(id = UUID.randomUUID().toString()) })
                }

                rawJson.contains("\"profiles\"") -> {
                    val bundle = json.decodeFromString<BianGregConfigBundle>(rawJson)
                    ConfigImportResult(
                        bundle.profiles.map {
                            it.copy(
                                id = UUID.randomUUID().toString(),
                                isLocked = it.isLocked || bundle.locked
                            )
                        }
                    )
                }

                else -> {
                    val single = json.decodeFromString<TunnelProfile>(rawJson)
                    ConfigImportResult(listOf(single.copy(id = UUID.randomUUID().toString())))
                }
            }
        }.getOrElse {
            ConfigImportResult(emptyList(), listOf("JSON config tidak valid: ${it.message}"))
        }
    }

    private fun parseVmessUri(uriString: String): TunnelProfile? {
        return runCatching {
            val b64 = uriString.substringAfter("://").trim()
            val decoded = String(decodeBase64Flexible(b64), Charsets.UTF_8)
            val obj = json.parseToJsonElement(decoded) as? JsonObject ?: return null
            val add = obj["add"]?.jsonPrimitive?.content ?: return null
            val port = obj["port"]?.jsonPrimitive?.intOrNull
                ?: obj["port"]?.jsonPrimitive?.content?.toIntOrNull()
                ?: 443
            val uuid = obj["id"]?.jsonPrimitive?.content ?: return null
            val ps = obj["ps"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() } ?: "VMess $add"
            val aid = obj["aid"]?.jsonPrimitive?.intOrNull
                ?: obj["aid"]?.jsonPrimitive?.content?.toIntOrNull()
                ?: 0
            val scy = obj["scy"]?.jsonPrimitive?.content ?: "auto"
            val net = obj["net"]?.jsonPrimitive?.content?.lowercase() ?: "tcp"
            val host = obj["host"]?.jsonPrimitive?.content ?: ""
            val path = obj["path"]?.jsonPrimitive?.content?.ifBlank { "/" } ?: "/"
            val tls = obj["tls"]?.jsonPrimitive?.content?.lowercase() ?: ""
            val sni = obj["sni"]?.jsonPrimitive?.content?.ifBlank { host } ?: host
            val fp = obj["fp"]?.jsonPrimitive?.content ?: "chrome"

            TunnelProfile(
                name = ps,
                protocol = TunnelProtocol.V2RAY_VMESS,
                v2rayAddress = add,
                v2rayPort = port,
                v2rayUuid = uuid,
                v2rayAlterId = aid,
                v2raySecurityMethod = scy,
                v2rayTransport = when (net) {
                    "ws" -> V2RayTransport.WS
                    "grpc" -> V2RayTransport.GRPC
                    else -> V2RayTransport.TCP
                },
                v2raySecurity = if (tls == "tls") V2RaySecurity.TLS else V2RaySecurity.NONE,
                v2raySni = sni,
                v2rayWsHost = host,
                v2rayWsPath = path,
                v2rayFingerprint = fp
            )
        }.getOrNull()
    }

    private fun parseVlessOrTrojanUri(uriString: String, isTrojan: Boolean): TunnelProfile? {
        return runCatching {
            val uri = URI(uriString)
            val host = uri.host ?: return null
            val port = if (uri.port > 0) uri.port else 443
            val credential = uri.userInfo ?: return null
            val query = parseQuery(uri.rawQuery)
            val fragment = uri.fragment?.let { urlDecode(it) }?.takeIf { it.isNotBlank() }
                ?: "${if (isTrojan) "Trojan" else "VLESS"} $host"

            val net = query["type"]?.lowercase() ?: "tcp"
            val securityStr = query["security"]?.lowercase() ?: if (isTrojan) "tls" else "none"
            val sni = query["sni"] ?: query["peer"] ?: ""
            val wsHost = query["host"] ?: sni
            val wsPath = query["path"] ?: "/"
            val fp = query["fp"] ?: "chrome"
            val pbk = query["pbk"] ?: ""
            val sid = query["sid"] ?: ""

            TunnelProfile(
                name = fragment,
                protocol = if (isTrojan) TunnelProtocol.V2RAY_TROJAN else TunnelProtocol.V2RAY_VLESS,
                v2rayAddress = host,
                v2rayPort = port,
                v2rayUuid = urlDecode(credential),
                v2rayTransport = when (net) {
                    "ws" -> V2RayTransport.WS
                    "grpc" -> V2RayTransport.GRPC
                    else -> V2RayTransport.TCP
                },
                v2raySecurity = when (securityStr) {
                    "reality" -> V2RaySecurity.REALITY
                    "tls" -> V2RaySecurity.TLS
                    else -> V2RaySecurity.NONE
                },
                v2raySni = sni,
                v2rayWsHost = wsHost,
                v2rayWsPath = wsPath,
                v2rayFingerprint = fp,
                v2rayPublicKey = pbk,
                v2rayShortId = sid
            )
        }.getOrNull()
    }

    private fun parseShadowsocksUri(uriString: String): TunnelProfile? {
        return runCatching {
            val withoutScheme = uriString.substringAfter("://")
            val fragment = withoutScheme.substringAfter("#", "").let { urlDecode(it) }
            val main = withoutScheme.substringBefore("#").substringBefore("?")

            val method: String
            val password: String
            val host: String
            val port: Int

            if (main.contains("@")) {
                val userInfo = main.substringBefore("@")
                val hostPort = main.substringAfter("@")
                val decodedUser = if (userInfo.contains(":")) {
                    userInfo
                } else {
                    String(decodeBase64Flexible(userInfo), Charsets.UTF_8)
                }
                method = decodedUser.substringBefore(":")
                password = decodedUser.substringAfter(":", "")
                host = hostPort.substringBefore(":")
                port = hostPort.substringAfter(":", "8388").toIntOrNull() ?: 8388
            } else {
                val decoded = String(decodeBase64Flexible(main), Charsets.UTF_8)
                val creds = decoded.substringBeforeLast("@")
                val hostPort = decoded.substringAfterLast("@")
                method = creds.substringBefore(":")
                password = creds.substringAfter(":", "")
                host = hostPort.substringBefore(":")
                port = hostPort.substringAfter(":", "8388").toIntOrNull() ?: 8388
            }

            if (host.isBlank()) return null

            TunnelProfile(
                name = fragment.ifBlank { "Shadowsocks $host" },
                protocol = TunnelProtocol.V2RAY_SHADOWSOCKS,
                v2rayAddress = host,
                v2rayPort = port,
                v2rayUuid = password,
                v2raySecurityMethod = method.ifBlank { "aes-256-gcm" },
                v2rayTransport = V2RayTransport.TCP,
                v2raySecurity = V2RaySecurity.NONE
            )
        }.getOrNull()
    }

    private fun parseSshUri(uriString: String): TunnelProfile? {
        return runCatching {
            val uri = URI(uriString)
            val host = uri.host ?: return null
            val port = if (uri.port > 0) uri.port else 22
            val userInfo = uri.userInfo ?: ""
            val username = urlDecode(userInfo.substringBefore(":"))
            val password = if (userInfo.contains(":")) urlDecode(userInfo.substringAfter(":")) else ""
            val query = parseQuery(uri.rawQuery)
            val mode = query["mode"]?.let { name ->
                TunnelProtocol.entries.firstOrNull { it.name == name && !it.isV2Ray }
            } ?: TunnelProtocol.SSH_PAYLOAD
            val proxyRaw = query["proxy"] ?: ""
            val proxyHost = proxyRaw.substringBefore(":", "")
            val proxyPort = proxyRaw.substringAfter(":", "8080").toIntOrNull() ?: 8080
            val sni = query["sni"] ?: ""
            val payload = query["payload"]
                ?: "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf][crlf]"
            val name = uri.fragment?.let { urlDecode(it) }?.takeIf { it.isNotBlank() } ?: "SSH $host"

            TunnelProfile(
                name = name,
                protocol = mode,
                sshHost = host,
                sshPort = port,
                sshUsername = username,
                sshPassword = password,
                proxyHost = proxyHost,
                proxyPort = proxyPort,
                sniHost = sni,
                payload = payload
            )
        }.getOrNull()
    }

    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split("&")
            .mapNotNull { part ->
                val idx = part.indexOf('=')
                if (idx <= 0) null
                else urlDecode(part.substring(0, idx)) to urlDecode(part.substring(idx + 1))
            }
            .toMap()
    }

    private fun decodeBase64Flexible(input: String): ByteArray {
        val cleaned = input.trim().replace('-', '+').replace('_', '/')
        val padded = when (cleaned.length % 4) {
            2 -> "$cleaned=="
            3 -> "$cleaned="
            else -> cleaned
        }
        return Base64.decode(padded, Base64.DEFAULT)
    }

    private fun urlEncode(value: String): String =
        URLEncoder.encode(value, Charsets.UTF_8.name()).replace("+", "%20")

    private fun urlDecode(value: String): String =
        URLDecoder.decode(value, Charsets.UTF_8.name())

    private fun escapeJson(value: String): String =
        value.replace("\\", "\\\\").replace("\"", "\\\"")
}
