package com.example.data.codec

enum class PayloadInjectMode(val label: String) {
    NORMAL("Normal"),
    FRONT_INJECT("Front Inject"),
    BACK_INJECT("Back Inject"),
    WEBSOCKET("WebSocket Upgrade")
}

enum class PayloadSplitMode(val label: String) {
    NONE("Tanpa Split"),
    SPLIT("Instant Split"),
    DELAY_SPLIT("Delay Split")
}

data class PayloadGeneratorOptions(
    val bugHost: String = "",
    val method: String = "GET",
    val injectMode: PayloadInjectMode = PayloadInjectMode.WEBSOCKET,
    val splitMode: PayloadSplitMode = PayloadSplitMode.NONE,
    val onlineHost: Boolean = true,
    val forwardHost: Boolean = false,
    val keepAlive: Boolean = true,
    val dualConnect: Boolean = false,
    val userAgent: Boolean = true
)

data class PayloadWireChunk(
    val bytes: ByteArray,
    val delayBeforeMs: Long = 0L
)

object PayloadGenerator {

    private const val DEFAULT_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"

    val quickTags: List<String> = listOf(
        "[crlf]",
        "[host_port]",
        "[host]",
        "[protocol]",
        "[split]",
        "[delay_split]",
        "[ua]",
        "[lf]"
    )

    fun generate(options: PayloadGeneratorOptions): String {
        val host = options.bugHost.trim().ifBlank { "bug.domain.com" }
        val method = options.method.uppercase().ifBlank { "GET" }

        val sb = StringBuilder()

        when (options.injectMode) {
            PayloadInjectMode.WEBSOCKET -> {
                sb.append("$method / [protocol][crlf]")
                sb.append("Host: $host[crlf]")
                sb.append("Upgrade: websocket[crlf]")
                sb.append("Connection: Upgrade[crlf]")
                if (options.userAgent) sb.append("User-Agent: [ua][crlf]")
                sb.append("[crlf]")
            }

            PayloadInjectMode.NORMAL -> {
                sb.append("CONNECT [host_port] [protocol][crlf]")
                if (options.onlineHost) sb.append("Host: $host[crlf]")
                if (options.forwardHost) sb.append("X-Forwarded-Host: $host[crlf]")
                if (options.keepAlive) sb.append("Connection: Keep-Alive[crlf]")
                if (options.userAgent) sb.append("User-Agent: [ua][crlf]")
                sb.append("[crlf]")
            }

            PayloadInjectMode.FRONT_INJECT -> {
                sb.append("$method http://$host/ [protocol][crlf]")
                sb.append("Host: $host[crlf]")
                if (options.forwardHost) sb.append("X-Forwarded-Host: $host[crlf]")
                if (options.keepAlive) sb.append("Connection: Keep-Alive[crlf]")
                if (options.userAgent) sb.append("User-Agent: [ua][crlf]")
                sb.append("[crlf]")
                when (options.splitMode) {
                    PayloadSplitMode.SPLIT -> sb.append("[split]")
                    PayloadSplitMode.DELAY_SPLIT -> sb.append("[delay_split]")
                    PayloadSplitMode.NONE -> Unit
                }
                sb.append("CONNECT [host_port] [protocol][crlf][crlf]")
            }

            PayloadInjectMode.BACK_INJECT -> {
                sb.append("CONNECT [host_port] [protocol][crlf]")
                if (options.dualConnect) {
                    sb.append("CONNECT [host_port] [protocol][crlf]")
                }
                sb.append("[crlf]")
                when (options.splitMode) {
                    PayloadSplitMode.SPLIT -> sb.append("[split]")
                    PayloadSplitMode.DELAY_SPLIT -> sb.append("[delay_split]")
                    PayloadSplitMode.NONE -> Unit
                }
                sb.append("$method http://$host/ [protocol][crlf]")
                sb.append("Host: $host[crlf]")
                if (options.onlineHost) sb.append("X-Online-Host: $host[crlf]")
                if (options.keepAlive) sb.append("Connection: Keep-Alive[crlf]")
                sb.append("[crlf]")
            }
        }

        if (options.injectMode == PayloadInjectMode.NORMAL || options.injectMode == PayloadInjectMode.WEBSOCKET) {
            when (options.splitMode) {
                PayloadSplitMode.SPLIT -> return sb.toString().replaceFirst("[crlf]", "[crlf][split]")
                PayloadSplitMode.DELAY_SPLIT -> return sb.toString().replaceFirst("[crlf]", "[crlf][delay_split]")
                PayloadSplitMode.NONE -> Unit
            }
        }

        return sb.toString()
    }

    fun buildWireChunks(
        template: String,
        targetHost: String,
        targetPort: Int,
        fallbackHost: String = targetHost
    ): List<PayloadWireChunk> {
        val resolvedHost = targetHost.ifBlank { fallbackHost }
        val expanded = template
            .replace("[host_port]", "$resolvedHost:$targetPort")
            .replace("[ssh]", "$resolvedHost:$targetPort")
            .replace("[host]", resolvedHost)
            .replace("[port]", targetPort.toString())
            .replace("[protocol]", "HTTP/1.1")
            .replace("[ua]", DEFAULT_USER_AGENT)
            .replace("[netdata]", "CONNECT $resolvedHost:$targetPort HTTP/1.1")
            .replace("[crlf]", "\r\n")
            .replace("[lf]", "\n")
            .replace("[cr]", "\r")

        val chunks = mutableListOf<PayloadWireChunk>()
        val tokenRegex = Regex("\\[(split|delay_split)]", RegexOption.IGNORE_CASE)
        var lastIndex = 0
        var pendingDelayMs = 0L

        for (match in tokenRegex.findAll(expanded)) {
            val part = expanded.substring(lastIndex, match.range.first)
            if (part.isNotEmpty()) {
                chunks.add(PayloadWireChunk(part.toByteArray(Charsets.UTF_8), pendingDelayMs))
            }
            pendingDelayMs = if (match.groupValues[1].equals("delay_split", ignoreCase = true)) 250L else 25L
            lastIndex = match.range.last + 1
        }
        val tail = expanded.substring(lastIndex)
        if (tail.isNotEmpty() || chunks.isEmpty()) {
            chunks.add(PayloadWireChunk(tail.toByteArray(Charsets.UTF_8), pendingDelayMs))
        }
        return chunks
    }
}
