package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TunnelProfileDao {
    @Query("SELECT * FROM tunnel_profiles ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<TunnelProfileEntity>>

    @Query("SELECT * FROM tunnel_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): TunnelProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: TunnelProfileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<TunnelProfileEntity>)

    @Query("UPDATE tunnel_profiles SET lastLatencyMs = :latencyMs WHERE id = :id")
    suspend fun updateLatency(id: String, latencyMs: Long?)

    @Query("DELETE FROM tunnel_profiles WHERE id = :id")
    suspend fun deleteById(id: String)
}
