package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.model.V2RaySecurity
import com.example.data.model.V2RayTransport

@Entity(tableName = "tunnel_profiles")
data class TunnelProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val protocolName: String,
    val sshHost: String,
    val sshPort: Int,
    val sshUsername: String,
    val sshPassword: String,
    val sshPrivateKey: String,
    val proxyHost: String,
    val proxyPort: Int,
    val sniHost: String,
    val payload: String,
    val v2rayAddress: String,
    val v2rayPort: Int,
    val v2rayUuid: String,
    val v2rayAlterId: Int,
    val v2raySecurityMethod: String,
    val v2rayTransportName: String,
    val v2raySecurityName: String,
    val v2raySni: String,
    val v2rayWsHost: String,
    val v2rayWsPath: String,
    val v2rayFingerprint: String,
    val v2rayPublicKey: String,
    val v2rayShortId: String,
    val isLocked: Boolean,
    val notes: String,
    val lastLatencyMs: Long?,
    val updatedAt: Long
) {
    fun toDomain(): TunnelProfile = TunnelProfile(
        id = id,
        name = name,
        protocol = TunnelProtocol.entries.firstOrNull { it.name == protocolName }
            ?: TunnelProtocol.SSH_PAYLOAD,
        sshHost = sshHost,
        sshPort = sshPort,
        sshUsername = sshUsername,
        sshPassword = sshPassword,
        sshPrivateKey = sshPrivateKey,
        proxyHost = proxyHost,
        proxyPort = proxyPort,
        sniHost = sniHost,
        payload = payload,
        v2rayAddress = v2rayAddress,
        v2rayPort = v2rayPort,
        v2rayUuid = v2rayUuid,
        v2rayAlterId = v2rayAlterId,
        v2raySecurityMethod = v2raySecurityMethod,
        v2rayTransport = V2RayTransport.entries.firstOrNull { it.name == v2rayTransportName }
            ?: V2RayTransport.WS,
        v2raySecurity = V2RaySecurity.entries.firstOrNull { it.name == v2raySecurityName }
            ?: V2RaySecurity.TLS,
        v2raySni = v2raySni,
        v2rayWsHost = v2rayWsHost,
        v2rayWsPath = v2rayWsPath,
        v2rayFingerprint = v2rayFingerprint,
        v2rayPublicKey = v2rayPublicKey,
        v2rayShortId = v2rayShortId,
        isLocked = isLocked,
        notes = notes,
        lastLatencyMs = lastLatencyMs,
        updatedAt = updatedAt
    )

    companion object {
        fun fromDomain(profile: TunnelProfile): TunnelProfileEntity = TunnelProfileEntity(
            id = profile.id,
            name = profile.name,
            protocolName = profile.protocol.name,
            sshHost = profile.sshHost,
            sshPort = profile.sshPort,
            sshUsername = profile.sshUsername,
            sshPassword = profile.sshPassword,
            sshPrivateKey = profile.sshPrivateKey,
            proxyHost = profile.proxyHost,
            proxyPort = profile.proxyPort,
            sniHost = profile.sniHost,
            payload = profile.payload,
            v2rayAddress = profile.v2rayAddress,
            v2rayPort = profile.v2rayPort,
            v2rayUuid = profile.v2rayUuid,
            v2rayAlterId = profile.v2rayAlterId,
            v2raySecurityMethod = profile.v2raySecurityMethod,
            v2rayTransportName = profile.v2rayTransport.name,
            v2raySecurityName = profile.v2raySecurity.name,
            v2raySni = profile.v2raySni,
            v2rayWsHost = profile.v2rayWsHost,
            v2rayWsPath = profile.v2rayWsPath,
            v2rayFingerprint = profile.v2rayFingerprint,
            v2rayPublicKey = profile.v2rayPublicKey,
            v2rayShortId = profile.v2rayShortId,
            isLocked = profile.isLocked,
            notes = profile.notes,
            lastLatencyMs = profile.lastLatencyMs,
            updatedAt = profile.updatedAt
        )
    }
}
