package com.example.data.model

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
enum class TunnelProtocol(
    val displayName: String,
    val shortBadge: String,
    val isV2Ray: Boolean,
    val usesPayload: Boolean,
    val usesSni: Boolean
) {
    SSH_DIRECT(
        displayName = "SSH Direct",
        shortBadge = "SSH",
        isV2Ray = false,
        usesPayload = false,
        usesSni = false
    ),
    SSH_PAYLOAD(
        displayName = "SSH + HTTP Payload",
        shortBadge = "SSH+HTTP",
        isV2Ray = false,
        usesPayload = true,
        usesSni = false
    ),
    SSH_SSL_SNI(
        displayName = "SSH + SSL/TLS (SNI)",
        shortBadge = "SSH+SSL",
        isV2Ray = false,
        usesPayload = true,
        usesSni = true
    ),
    SSH_WEBSOCKET(
        displayName = "SSH + WebSocket",
        shortBadge = "SSH+WS",
        isV2Ray = false,
        usesPayload = true,
        usesSni = true
    ),
    V2RAY_VLESS(
        displayName = "V2Ray VLESS",
        shortBadge = "VLESS",
        isV2Ray = true,
        usesPayload = false,
        usesSni = true
    ),
    V2RAY_VMESS(
        displayName = "V2Ray VMess",
        shortBadge = "VMess",
        isV2Ray = true,
        usesPayload = false,
        usesSni = true
    ),
    V2RAY_TROJAN(
        displayName = "V2Ray Trojan",
        shortBadge = "Trojan",
        isV2Ray = true,
        usesPayload = false,
        usesSni = true
    ),
    V2RAY_SHADOWSOCKS(
        displayName = "Shadowsocks",
        shortBadge = "SS",
        isV2Ray = true,
        usesPayload = false,
        usesSni = false
    )
}

@Serializable
enum class V2RayTransport(val wireValue: String, val label: String) {
    TCP("tcp", "TCP"),
    WS("ws", "WebSocket"),
    GRPC("grpc", "gRPC")
}

@Serializable
enum class V2RaySecurity(val wireValue: String, val label: String) {
    NONE("none", "None"),
    TLS("tls", "TLS"),
    REALITY("reality", "Reality")
}

@Serializable
data class TunnelProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Profil Baru",
    val protocol: TunnelProtocol = TunnelProtocol.SSH_PAYLOAD,

    // SSH & Payload settings
    val sshHost: String = "",
    val sshPort: Int = 22,
    val sshUsername: String = "",
    val sshPassword: String = "",
    val sshPrivateKey: String = "",
    val proxyHost: String = "",
    val proxyPort: Int = 8080,
    val sniHost: String = "",
    val payload: String = "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf][crlf]",

    // V2Ray / Xray settings
    val v2rayAddress: String = "",
    val v2rayPort: Int = 443,
    val v2rayUuid: String = "",
    val v2rayAlterId: Int = 0,
    val v2raySecurityMethod: String = "auto",
    val v2rayTransport: V2RayTransport = V2RayTransport.WS,
    val v2raySecurity: V2RaySecurity = V2RaySecurity.TLS,
    val v2raySni: String = "",
    val v2rayWsHost: String = "",
    val v2rayWsPath: String = "/",
    val v2rayFingerprint: String = "chrome",
    val v2rayPublicKey: String = "",
    val v2rayShortId: String = "",

    // Metadata
    val isLocked: Boolean = false,
    val notes: String = "",
    val lastLatencyMs: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun primaryHost(): String = if (protocol.isV2Ray) v2rayAddress else sshHost
    fun primaryPort(): Int = if (protocol.isV2Ray) v2rayPort else sshPort

    fun endpointSummary(): String {
        val h = primaryHost().ifBlank { "belum diatur" }
        val p = primaryPort()
        return "$h:$p"
    }

    fun isConfigured(): Boolean {
        return if (protocol.isV2Ray) {
            v2rayAddress.isNotBlank() && v2rayPort in 1..65535 &&
                (protocol == TunnelProtocol.V2RAY_SHADOWSOCKS || v2rayUuid.isNotBlank())
        } else {
            sshHost.isNotBlank() && sshPort in 1..65535 && sshUsername.isNotBlank()
        }
    }
}

enum class VpnConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    ERROR
}

data class TunnelTelemetry(
    val status: VpnConnectionState = VpnConnectionState.DISCONNECTED,
    val activeProfileId: String? = null,
    val activeProfileName: String = "",
    val activeProtocol: TunnelProtocol? = null,
    val connectedSinceMs: Long? = null,
    val bytesUp: Long = 0L,
    val bytesDown: Long = 0L,
    val speedUpBps: Long = 0L,
    val speedDownBps: Long = 0L,
    val speedHistoryUp: List<Long> = List(24) { 0L },
    val speedHistoryDown: List<Long> = List(24) { 0L },
    val lastLatencyMs: Long? = null,
    val errorMessage: String? = null,
    val localTunnelIp: String = "10.88.0.2"
)

enum class LogLevel(val tag: String) {
    INFO("INFO"),
    PAYLOAD("PYLD"),
    NET("NET"),
    WARN("WARN"),
    ERR("ERR")
}

data class TunnelLogEntry(
    val id: Long,
    val timestamp: Long,
    val level: LogLevel,
    val message: String
)

data class AppSettings(
    val activeProfileId: String? = null,
    val dnsPrimary: String = "1.1.1.1",
    val dnsSecondary: String = "8.8.8.8",
    val wakeLockEnabled: Boolean = true,
    val autoReconnect: Boolean = true,
    val darkTheme: Boolean = true
)
