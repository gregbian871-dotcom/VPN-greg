package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.local.TunnelProfileDao
import com.example.data.local.TunnelProfileEntity
import com.example.data.model.AppSettings
import com.example.data.model.TunnelProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.tunnelPrefsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "biangreg_tunnel_prefs"
)

class TunnelRepository(
    private val context: Context,
    private val dao: TunnelProfileDao
) {
    private object Keys {
        val ACTIVE_PROFILE_ID = stringPreferencesKey("active_profile_id")
        val DNS_PRIMARY = stringPreferencesKey("dns_primary")
        val DNS_SECONDARY = stringPreferencesKey("dns_secondary")
        val WAKE_LOCK = booleanPreferencesKey("wake_lock")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
    }

    val profiles: Flow<List<TunnelProfile>> = dao.observeAll().map { list ->
        list.map { it.toDomain() }
    }

    val settings: Flow<AppSettings> = context.tunnelPrefsDataStore.data.map { prefs ->
        AppSettings(
            activeProfileId = prefs[Keys.ACTIVE_PROFILE_ID],
            dnsPrimary = prefs[Keys.DNS_PRIMARY] ?: "1.1.1.1",
            dnsSecondary = prefs[Keys.DNS_SECONDARY] ?: "8.8.8.8",
            wakeLockEnabled = prefs[Keys.WAKE_LOCK] ?: true,
            autoReconnect = prefs[Keys.AUTO_RECONNECT] ?: true,
            darkTheme = prefs[Keys.DARK_THEME] ?: true
        )
    }

    suspend fun getProfileById(id: String): TunnelProfile? = dao.getById(id)?.toDomain()

    suspend fun getCurrentSettings(): AppSettings = settings.first()

    suspend fun saveProfile(profile: TunnelProfile) {
        dao.upsert(TunnelProfileEntity.fromDomain(profile.copy(updatedAt = System.currentTimeMillis())))
    }

    suspend fun saveProfiles(profiles: List<TunnelProfile>) {
        val now = System.currentTimeMillis()
        dao.upsertAll(profiles.map { TunnelProfileEntity.fromDomain(it.copy(updatedAt = now)) })
    }

    suspend fun updateLatency(id: String, latencyMs: Long?) {
        dao.updateLatency(id, latencyMs)
    }

    suspend fun deleteProfile(id: String) {
        dao.deleteById(id)
    }

    suspend fun setActiveProfileId(id: String?) {
        context.tunnelPrefsDataStore.edit { prefs ->
            if (id == null) prefs.remove(Keys.ACTIVE_PROFILE_ID)
            else prefs[Keys.ACTIVE_PROFILE_ID] = id
        }
    }

    suspend fun updateDns(primary: String, secondary: String) {
        context.tunnelPrefsDataStore.edit { prefs ->
            prefs[Keys.DNS_PRIMARY] = primary.trim().ifBlank { "1.1.1.1" }
            prefs[Keys.DNS_SECONDARY] = secondary.trim().ifBlank { "8.8.8.8" }
        }
    }

    suspend fun setWakeLock(enabled: Boolean) {
        context.tunnelPrefsDataStore.edit { it[Keys.WAKE_LOCK] = enabled }
    }

    suspend fun setAutoReconnect(enabled: Boolean) {
        context.tunnelPrefsDataStore.edit { it[Keys.AUTO_RECONNECT] = enabled }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.tunnelPrefsDataStore.edit { it[Keys.DARK_THEME] = enabled }
    }
}
