package com.example.ui

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.codec.ConfigCodec
import com.example.data.codec.PayloadGenerator
import com.example.data.codec.PayloadGeneratorOptions
import com.example.data.local.AppDatabase
import com.example.data.model.AppSettings
import com.example.data.model.LogLevel
import com.example.data.model.TunnelLogEntry
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.model.TunnelTelemetry
import com.example.data.repository.TunnelRepository
import com.example.vpn.BianGregVpnService
import com.example.vpn.HandshakeTestResult
import com.example.vpn.NetworkProbe
import com.example.vpn.VpnStateHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class ConfigFilter(val label: String) {
    ALL("Semua"),
    SSH("SSH / Payload"),
    V2RAY("V2Ray")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TunnelRepository(
        context = application.applicationContext,
        dao = AppDatabase.getInstance(application.applicationContext).tunnelProfileDao()
    )

    val profiles: StateFlow<List<TunnelProfile>> = repository.profiles.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val settings: StateFlow<AppSettings> = repository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    val activeProfile: StateFlow<TunnelProfile?> = combine(profiles, settings) { list, prefs ->
        list.firstOrNull { it.id == prefs.activeProfileId } ?: list.firstOrNull()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val telemetry: StateFlow<TunnelTelemetry> = VpnStateHolder.telemetry
    val logs: StateFlow<List<TunnelLogEntry>> = VpnStateHolder.logs

    private val _editorDraft = MutableStateFlow(TunnelProfile())
    val editorDraft: StateFlow<TunnelProfile> = _editorDraft.asStateFlow()

    private val _isProbing = MutableStateFlow(false)
    val isProbing: StateFlow<Boolean> = _isProbing.asStateFlow()

    private val _handshakeResult = MutableStateFlow<HandshakeTestResult?>(null)
    val handshakeResult: StateFlow<HandshakeTestResult?> = _handshakeResult.asStateFlow()

    private val _configFilter = MutableStateFlow(ConfigFilter.ALL)
    val configFilter: StateFlow<ConfigFilter> = _configFilter.asStateFlow()

    private val _pendingExportContent = MutableStateFlow<String?>(null)
    val pendingExportContent: StateFlow<String?> = _pendingExportContent.asStateFlow()

    private val _uiMessage = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val uiMessage: SharedFlow<String> = _uiMessage.asSharedFlow()

    fun updateDraft(transform: (TunnelProfile) -> TunnelProfile) {
        _editorDraft.update { current ->
            if (current.isLocked) current else transform(current)
        }
    }

    fun startNewDraft(protocol: TunnelProtocol = TunnelProtocol.SSH_PAYLOAD) {
        _handshakeResult.value = null
        _editorDraft.value = TunnelProfile(
            id = UUID.randomUUID().toString(),
            name = if (protocol.isV2Ray) "Config ${protocol.shortBadge}" else "SSH Payload Baru",
            protocol = protocol
        )
    }

    fun loadProfileToEditor(profile: TunnelProfile) {
        _handshakeResult.value = null
        _editorDraft.value = profile
    }

    fun saveEditorDraft(activateAfterSave: Boolean = true) {
        val draft = _editorDraft.value
        if (draft.isLocked) {
            emitMessage("Config terkunci (.bgt) tidak dapat dimodifikasi.")
            return
        }
        val cleanName = draft.name.trim().ifBlank {
            val h = draft.primaryHost().ifBlank { "Tunnel" }
            "${draft.protocol.shortBadge} $h"
        }
        val toSave = draft.copy(name = cleanName, updatedAt = System.currentTimeMillis())
        viewModelScope.launch {
            repository.saveProfile(toSave)
            if (activateAfterSave) {
                repository.setActiveProfileId(toSave.id)
            }
            _editorDraft.value = toSave
            VpnStateHolder.log(LogLevel.INFO, "Profil disimpan: ${toSave.name} (${toSave.protocol.shortBadge})")
            emitMessage("Profil \"${toSave.name}\" tersimpan.")
        }
    }

    fun selectActiveProfile(profile: TunnelProfile) {
        viewModelScope.launch {
            repository.setActiveProfileId(profile.id)
            VpnStateHolder.log(LogLevel.INFO, "Profil aktif diganti ke: ${profile.name}")
            emitMessage("Profil aktif: ${profile.name}")
        }
    }

    fun deleteProfile(profile: TunnelProfile) {
        viewModelScope.launch {
            repository.deleteProfile(profile.id)
            if (settings.value.activeProfileId == profile.id) {
                val next = profiles.value.firstOrNull { it.id != profile.id }
                repository.setActiveProfileId(next?.id)
            }
            emitMessage("Profil \"${profile.name}\" dihapus.")
        }
    }

    fun applyGeneratedPayload(options: PayloadGeneratorOptions) {
        val generated = PayloadGenerator.generate(options)
        _editorDraft.update { current ->
            if (current.isLocked) current else current.copy(payload = generated)
        }
        VpnStateHolder.log(LogLevel.PAYLOAD, "Payload baru dibuat (${options.injectMode.label}).")
    }

    fun appendPayloadTag(tag: String) {
        _editorDraft.update { current ->
            if (current.isLocked) current else current.copy(payload = current.payload + tag)
        }
    }

    fun testDraftHandshake() {
        val draft = _editorDraft.value
        if (draft.primaryHost().isBlank()) {
            emitMessage("Isi host server terlebih dahulu sebelum uji handshake.")
            return
        }
        viewModelScope.launch {
            _isProbing.value = true
            VpnStateHolder.log(
                LogLevel.NET,
                "Menguji handshake ${draft.protocol.shortBadge} ke ${draft.endpointSummary()}..."
            )
            val result = NetworkProbe.testHandshake(draft)
            _handshakeResult.value = result
            _isProbing.value = false
            VpnStateHolder.log(
                if (result.success) LogLevel.NET else LogLevel.ERR,
                "${result.summary} | ${result.serverResponse.lineSequence().firstOrNull().orEmpty()}"
            )
        }
    }

    fun probeActiveProfileLatency() {
        val profile = activeProfile.value
        if (profile == null || profile.primaryHost().isBlank()) {
            emitMessage("Pilih atau buat profil aktif terlebih dahulu.")
            return
        }
        val probeHost = if (!profile.protocol.isV2Ray && profile.proxyHost.isNotBlank()) {
            profile.proxyHost
        } else {
            profile.primaryHost()
        }
        val probePort = if (!profile.protocol.isV2Ray && profile.proxyHost.isNotBlank()) {
            profile.proxyPort
        } else {
            profile.primaryPort()
        }

        viewModelScope.launch {
            _isProbing.value = true
            val res = NetworkProbe.probeTcpLatency(probeHost, probePort)
            _isProbing.value = false
            res.onSuccess { ms ->
                repository.updateLatency(profile.id, ms)
                VpnStateHolder.updateLatency(ms)
                VpnStateHolder.log(LogLevel.NET, "Ping TCP $probeHost:$probePort -> ${ms} ms")
                emitMessage("Ping $probeHost:$probePort = $ms ms")
            }.onFailure { err ->
                VpnStateHolder.log(LogLevel.ERR, "Ping gagal ($probeHost:$probePort): ${err.message}")
                emitMessage("Ping gagal: ${err.message}")
            }
        }
    }

    fun importConfigText(rawText: String, loadIntoEditor: Boolean = false) {
        val result = ConfigCodec.importAny(rawText)
        if (result.profiles.isEmpty()) {
            val err = result.warnings.firstOrNull() ?: "Tidak ada konfigurasi valid ditemukan."
            VpnStateHolder.log(LogLevel.ERR, "Import gagal: $err")
            emitMessage(err)
            return
        }
        viewModelScope.launch {
            repository.saveProfiles(result.profiles)
            val first = result.profiles.first()
            repository.setActiveProfileId(first.id)
            if (loadIntoEditor) {
                _editorDraft.value = first
            }
            VpnStateHolder.log(
                LogLevel.INFO,
                "Berhasil import ${result.profiles.size} config (${first.name})."
            )
            val warnSuffix = if (result.warnings.isNotEmpty()) {
                " (${result.warnings.size} baris dilewati)"
            } else ""
            emitMessage("${result.profiles.size} config berhasil diimport$warnSuffix.")
        }
    }

    fun importFromUri(contentResolver: ContentResolver, uri: Uri) {
        viewModelScope.launch {
            val raw = withContext(Dispatchers.IO) {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }
            if (raw.isNullOrBlank()) {
                emitMessage("File config kosong atau tidak dapat dibaca.")
                return@launch
            }
            importConfigText(raw)
        }
    }

    fun prepareExportBundle(profilesToExport: List<TunnelProfile>, lockCredentials: Boolean): String {
        val content = ConfigCodec.exportBundle(profilesToExport, lockCredentials)
        _pendingExportContent.value = content
        return content
    }

    fun writePendingExportToUri(contentResolver: ContentResolver, uri: Uri) {
        val content = _pendingExportContent.value ?: return
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                        out.flush()
                    }
                }.isSuccess
            }
            _pendingExportContent.value = null
            if (ok) {
                VpnStateHolder.log(LogLevel.INFO, "Config berhasil diekspor ke file.")
                emitMessage("Config berhasil diekspor.")
            } else {
                emitMessage("Gagal menyimpan file ekspor.")
            }
        }
    }

    fun exportShareUri(profile: TunnelProfile): String {
        return ConfigCodec.exportShareUri(profile)
    }

    fun setConfigFilter(filter: ConfigFilter) {
        _configFilter.value = filter
    }

    fun updateDns(primary: String, secondary: String) {
        viewModelScope.launch {
            repository.updateDns(primary, secondary)
            VpnStateHolder.log(LogLevel.INFO, "DNS diperbarui: $primary / $secondary")
            emitMessage("DNS tersimpan.")
        }
    }

    fun setWakeLock(enabled: Boolean) {
        viewModelScope.launch { repository.setWakeLock(enabled) }
    }

    fun setAutoReconnect(enabled: Boolean) {
        viewModelScope.launch { repository.setAutoReconnect(enabled) }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch { repository.setDarkTheme(enabled) }
    }

    fun connectActiveProfile() {
        val profile = activeProfile.value
        if (profile == null) {
            emitMessage("Buat atau import config terlebih dahulu.")
            return
        }
        if (!profile.isConfigured()) {
            emitMessage("Lengkapi host/kredensial pada profil \"${profile.name}\" terlebih dahulu.")
            return
        }
        BianGregVpnService.startConnect(getApplication(), profile.id)
    }

    fun disconnectVpn() {
        BianGregVpnService.stopTunnel(getApplication())
    }

    fun clearLogs() {
        VpnStateHolder.clearLogs()
    }

    fun emitMessage(msg: String) {
        _uiMessage.tryEmit(msg)
    }
}
