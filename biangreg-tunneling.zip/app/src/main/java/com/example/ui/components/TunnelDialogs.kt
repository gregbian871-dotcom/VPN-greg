package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.codec.PayloadGeneratorOptions
import com.example.data.codec.PayloadInjectMode
import com.example.data.codec.PayloadSplitMode
import com.example.ui.theme.MonoCodeStyle

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PayloadGeneratorDialog(
    initialBugHost: String,
    onDismiss: () -> Unit,
    onGenerate: (PayloadGeneratorOptions) -> Unit
) {
    var bugHost by remember { mutableStateOf(initialBugHost) }
    var method by remember { mutableStateOf("GET") }
    var injectMode by remember { mutableStateOf(PayloadInjectMode.WEBSOCKET) }
    var splitMode by remember { mutableStateOf(PayloadSplitMode.NONE) }
    var onlineHost by remember { mutableStateOf(true) }
    var forwardHost by remember { mutableStateOf(false) }
    var keepAlive by remember { mutableStateOf(true) }
    var dualConnect by remember { mutableStateOf(false) }
    var userAgent by remember { mutableStateOf(true) }

    val methods = listOf("GET", "POST", "CONNECT", "HEAD", "PUT", "OPTIONS")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Payload Generator", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = bugHost,
                    onValueChange = { bugHost = it },
                    label = { Text("Bug Host / URL SNI") },
                    placeholder = { Text("contoh: cdn.domain.com") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payload_gen_bughost_input")
                )

                Text("Metode HTTP", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    methods.forEach { m ->
                        FilterChip(
                            selected = method == m,
                            onClick = { method = m },
                            label = { Text(m) }
                        )
                    }
                }

                Text("Mode Injeksi", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PayloadInjectMode.entries.forEach { mode ->
                        FilterChip(
                            selected = injectMode == mode,
                            onClick = { injectMode = mode },
                            label = { Text(mode.label) }
                        )
                    }
                }

                Text("Split Packet", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PayloadSplitMode.entries.forEach { sp ->
                        FilterChip(
                            selected = splitMode == sp,
                            onClick = { splitMode = sp },
                            label = { Text(sp.label) }
                        )
                    }
                }

                Text("Header Tambahan", style = MaterialTheme.typography.labelLarge)
                Column {
                    CheckOptionRow("Online Host", onlineHost) { onlineHost = it }
                    CheckOptionRow("Forward Host", forwardHost) { forwardHost = it }
                    CheckOptionRow("Keep-Alive", keepAlive) { keepAlive = it }
                    CheckOptionRow("Dual Connect", dualConnect) { dualConnect = it }
                    CheckOptionRow("User-Agent", userAgent) { userAgent = it }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onGenerate(
                        PayloadGeneratorOptions(
                            bugHost = bugHost,
                            method = method,
                            injectMode = injectMode,
                            splitMode = splitMode,
                            onlineHost = onlineHost,
                            forwardHost = forwardHost,
                            keepAlive = keepAlive,
                            dualConnect = dualConnect,
                            userAgent = userAgent
                        )
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("payload_gen_confirm_button")
            ) {
                Text("Buat Payload")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
private fun CheckOptionRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ImportTextDialog(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit,
    onPickFile: () -> Unit
) {
    var rawText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import Config", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Tempel link vmess://, vless://, trojan://, ss://, ssh://, kode BGT1:, atau JSON config di bawah ini.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = rawText,
                    onValueChange = { rawText = it },
                    label = { Text("Teks / Link Config") },
                    textStyle = MonoCodeStyle,
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("import_config_text_input")
                )
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onPickFile()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("import_pick_file_button")
                ) {
                    Text("Pilih File (.bgt / .json / .txt)")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onImport(rawText)
                    onDismiss()
                },
                enabled = rawText.isNotBlank(),
                modifier = Modifier.testTag("import_confirm_button")
            ) {
                Text("Import")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun ExportConfigDialog(
    title: String,
    profileCount: Int,
    onDismiss: () -> Unit,
    onExportFile: (lockCredentials: Boolean) -> Unit,
    onCopyText: (lockCredentials: Boolean) -> Unit
) {
    var lockCredentials by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Jumlah profil yang diekspor: $profileCount",
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Kunci Config (.bgt)", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Kredensial SSH/V2Ray & payload dikunci agar tidak dapat diedit saat diimport.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = lockCredentials,
                        onCheckedChange = { lockCredentials = it },
                        modifier = Modifier.testTag("export_lock_switch")
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedButton(
                    onClick = {
                        onCopyText(lockCredentials)
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("export_copy_text_button")
                ) {
                    Text("Salin Teks Config ke Clipboard")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onExportFile(lockCredentials)
                    onDismiss()
                },
                modifier = Modifier.testTag("export_save_file_button")
            ) {
                Text("Simpan ke File")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun DnsSettingsDialog(
    currentPrimary: String,
    currentSecondary: String,
    wakeLockEnabled: Boolean,
    autoReconnect: Boolean,
    darkTheme: Boolean,
    onDismiss: () -> Unit,
    onSaveDns: (String, String) -> Unit,
    onWakeLockChange: (Boolean) -> Unit,
    onAutoReconnectChange: (Boolean) -> Unit,
    onDarkThemeChange: (Boolean) -> Unit
) {
    var primary by remember { mutableStateOf(currentPrimary) }
    var secondary by remember { mutableStateOf(currentSecondary) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengaturan Tunnel & DNS", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = primary == "1.1.1.1",
                        onClick = { primary = "1.1.1.1"; secondary = "1.0.0.1" },
                        label = { Text("Cloudflare") }
                    )
                    FilterChip(
                        selected = primary == "8.8.8.8",
                        onClick = { primary = "8.8.8.8"; secondary = "8.8.4.4" },
                        label = { Text("Google") }
                    )
                    FilterChip(
                        selected = primary == "9.9.9.9",
                        onClick = { primary = "9.9.9.9"; secondary = "149.112.112.112" },
                        label = { Text("Quad9") }
                    )
                }
                OutlinedTextField(
                    value = primary,
                    onValueChange = { primary = it },
                    label = { Text("DNS Primer") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = secondary,
                    onValueChange = { secondary = it },
                    label = { Text("DNS Sekunder") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                SettingToggleRow("CPU WakeLock (Tetap Aktif)", wakeLockEnabled, onWakeLockChange)
                SettingToggleRow("Auto-Reconnect", autoReconnect, onAutoReconnectChange)
                SettingToggleRow("Tema Gelap Taktis", darkTheme, onDarkThemeChange)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSaveDns(primary, secondary)
                    onDismiss()
                },
                modifier = Modifier.testTag("dns_save_button")
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup")
            }
        }
    )
}

@Composable
private fun SettingToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
