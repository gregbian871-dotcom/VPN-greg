package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.TunnelProfile
import com.example.ui.ConfigFilter
import com.example.ui.theme.MonoCodeStyle

@Composable
fun ConfigManagerScreen(
    profiles: List<TunnelProfile>,
    activeProfileId: String?,
    filter: ConfigFilter,
    onFilterChange: (ConfigFilter) -> Unit,
    onSelectProfile: (TunnelProfile) -> Unit,
    onEditProfile: (TunnelProfile) -> Unit,
    onDeleteProfile: (TunnelProfile) -> Unit,
    onCreateNew: () -> Unit,
    onImportFile: () -> Unit,
    onImportText: () -> Unit,
    onExportAll: () -> Unit,
    onExportSingle: (TunnelProfile) -> Unit,
    onCopyShareUri: (TunnelProfile) -> Unit,
    onShareUri: (TunnelProfile) -> Unit
) {
    val filtered = profiles.filter { p ->
        when (filter) {
            ConfigFilter.ALL -> true
            ConfigFilter.SSH -> !p.protocol.isV2Ray
            ConfigFilter.V2RAY -> p.protocol.isV2Ray
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Manajer Config", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Import & Export .bgt, JSON, atau URI V2Ray/SSH",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    FilledTonalButton(
                        onClick = onCreateNew,
                        modifier = Modifier.testTag("configs_create_new_button")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Baru")
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onImportFile,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("configs_import_file_button")
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Import File")
                    }
                    OutlinedButton(
                        onClick = onImportText,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("configs_import_link_button")
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Import Link")
                    }
                    FilledTonalButton(
                        onClick = onExportAll,
                        enabled = profiles.isNotEmpty(),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("configs_export_all_button")
                    ) {
                        Icon(Icons.Rounded.Upload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Export")
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ConfigFilter.entries.forEach { itemFilter ->
                        FilterChip(
                            selected = filter == itemFilter,
                            onClick = { onFilterChange(itemFilter) },
                            label = { Text(itemFilter.label) }
                        )
                    }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyConfigState(
                        onCreateNew = onCreateNew,
                        onImportText = onImportText
                    )
                }
            } else {
                items(filtered, key = { it.id }) { profile ->
                    ConfigProfileCard(
                        profile = profile,
                        isActive = profile.id == activeProfileId,
                        onSelect = { onSelectProfile(profile) },
                        onEdit = { onEditProfile(profile) },
                        onExport = { onExportSingle(profile) },
                        onCopyUri = { onCopyShareUri(profile) },
                        onShareUri = { onShareUri(profile) },
                        onDelete = { onDeleteProfile(profile) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyConfigState(
    onCreateNew: () -> Unit,
    onImportText: () -> Unit
) {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.VpnKey,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
            Text("Belum Ada Config Tersimpan", style = MaterialTheme.typography.titleMedium)
            Text(
                "Tambahkan akun SSH + Payload, SSL/SNI, atau tempel link vmess://, vless://, trojan://, ss://.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onCreateNew) {
                    Text("Buat Config")
                }
                OutlinedButton(onClick = onImportText) {
                    Text("Tempel Link")
                }
            }
        }
    }
}

@Composable
private fun ConfigProfileCard(
    profile: TunnelProfile,
    isActive: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onExport: () -> Unit,
    onCopyUri: () -> Unit,
    onShareUri: () -> Unit,
    onDelete: () -> Unit
) {
    val borderColor = if (isActive) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.outlineVariant
    }

    OutlinedCard(
        onClick = onSelect,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("config_card_${profile.id}"),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(if (isActive) 1.5.dp else 1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (isActive) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = "Profil aktif",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = profile.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (profile.isLocked) {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = "Terkunci",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = profile.protocol.shortBadge,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Text(
                text = buildString {
                    append(profile.endpointSummary())
                    profile.lastLatencyMs?.let { append(" • ${it}ms") }
                },
                style = MonoCodeStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Edit config")
                    }
                    IconButton(
                        onClick = onExport,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Rounded.Upload, contentDescription = "Ekspor file config")
                    }
                    if (!profile.isLocked) {
                        IconButton(
                            onClick = onCopyUri,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Salin URI config")
                        }
                        IconButton(
                            onClick = onShareUri,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Rounded.Share, contentDescription = "Bagikan config")
                        }
                    }
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        Icons.Rounded.DeleteOutline,
                        contentDescription = "Hapus config",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}
