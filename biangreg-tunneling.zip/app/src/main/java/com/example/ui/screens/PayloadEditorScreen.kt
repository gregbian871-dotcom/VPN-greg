package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.codec.PayloadGenerator
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.model.V2RaySecurity
import com.example.data.model.V2RayTransport
import com.example.ui.theme.MonoCodeStyle
import com.example.vpn.HandshakeTestResult

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PayloadEditorScreen(
    draft: TunnelProfile,
    isProbing: Boolean,
    handshakeResult: HandshakeTestResult?,
    onUpdateDraft: ((TunnelProfile) -> TunnelProfile) -> Unit,
    onNewDraft: (TunnelProtocol) -> Unit,
    onOpenPayloadGenerator: () -> Unit,
    onAppendTag: (String) -> Unit,
    onOpenImportPaste: () -> Unit,
    onTestHandshake: () -> Unit,
    onSaveProfile: () -> Unit
) {
    var showPassword by remember { mutableStateOf(false) }
    val sshProtocols = remember { TunnelProtocol.entries.filter { !it.isV2Ray } }
    val v2rayProtocols = remember { TunnelProtocol.entries.filter { it.isV2Ray } }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Editor Payload & Akun", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Konfigurasi SSH Payload, SSL/SNI, atau V2Ray",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { onNewDraft(draft.protocol) },
                            modifier = Modifier.testTag("editor_new_draft_button")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Baru")
                        }
                    }
                }
            }

            if (draft.isLocked) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = "Terkunci")
                            Text(
                                "Config ini terkunci (.bgt). Anda tetap dapat menghubungkannya atau membuat profil baru.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            item {
                val isV2RayMode = draft.protocol.isV2Ray
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !isV2RayMode,
                        onClick = {
                            if (isV2RayMode && !draft.isLocked) {
                                onUpdateDraft { it.copy(protocol = TunnelProtocol.SSH_PAYLOAD) }
                            }
                        },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("editor_tab_ssh")
                    ) {
                        Text("SSH & Payload")
                    }
                    SegmentedButton(
                        selected = isV2RayMode,
                        onClick = {
                            if (!isV2RayMode && !draft.isLocked) {
                                onUpdateDraft { it.copy(protocol = TunnelProtocol.V2RAY_VLESS) }
                            }
                        },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("editor_tab_v2ray")
                    ) {
                        Text("V2Ray / Xray")
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = draft.name,
                    onValueChange = { v -> onUpdateDraft { it.copy(name = v) } },
                    label = { Text("Nama Profil") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_profile_name_input")
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Protokol Tunnel", style = MaterialTheme.typography.labelLarge)
                    val choices = if (draft.protocol.isV2Ray) v2rayProtocols else sshProtocols
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        choices.forEach { proto ->
                            FilterChip(
                                selected = draft.protocol == proto,
                                enabled = !draft.isLocked,
                                onClick = { onUpdateDraft { it.copy(protocol = proto) } },
                                label = { Text(proto.displayName) }
                            )
                        }
                    }
                }
            }

            if (!draft.protocol.isV2Ray) {
                item {
                    SshAccountSection(
                        draft = draft,
                        showPassword = showPassword,
                        onTogglePassword = { showPassword = !showPassword },
                        onUpdateDraft = onUpdateDraft
                    )
                }

                if (draft.protocol.usesPayload) {
                    item {
                        PayloadEditorSection(
                            draft = draft,
                            onUpdateDraft = onUpdateDraft,
                            onOpenPayloadGenerator = onOpenPayloadGenerator,
                            onAppendTag = onAppendTag
                        )
                    }
                }
            } else {
                item {
                    V2RayAccountSection(
                        draft = draft,
                        onUpdateDraft = onUpdateDraft,
                        onOpenImportPaste = onOpenImportPaste
                    )
                }
            }

            item {
                AnimatedVisibility(visible = handshakeResult != null) {
                    handshakeResult?.let { res ->
                        HandshakeResultCard(result = res)
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onTestHandshake,
                        enabled = !isProbing,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("editor_test_handshake_button")
                    ) {
                        if (isProbing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Rounded.NetworkCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text("Uji Koneksi")
                    }

                    Button(
                        onClick = onSaveProfile,
                        enabled = !draft.isLocked,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("editor_save_profile_button")
                    ) {
                        Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Simpan Profil")
                    }
                }
            }
        }
    }
}

@Composable
private fun SshAccountSection(
    draft: TunnelProfile,
    showPassword: Boolean,
    onTogglePassword: () -> Unit,
    onUpdateDraft: ((TunnelProfile) -> TunnelProfile) -> Unit
) {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Akun SSH & Proxy", style = MaterialTheme.typography.titleMedium)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = draft.sshHost,
                    onValueChange = { v -> onUpdateDraft { it.copy(sshHost = v) } },
                    label = { Text("Host / IP SSH") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    modifier = Modifier
                        .weight(2f)
                        .testTag("editor_ssh_host_input")
                )
                OutlinedTextField(
                    value = draft.sshPort.toString(),
                    onValueChange = { v ->
                        val p = v.filter { it.isDigit() }.toIntOrNull() ?: 22
                        onUpdateDraft { it.copy(sshPort = p) }
                    },
                    label = { Text("Port") },
                    enabled = !draft.isLocked,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = draft.sshUsername,
                    onValueChange = { v -> onUpdateDraft { it.copy(sshUsername = v) } },
                    label = { Text("Username") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("editor_ssh_user_input")
                )
                OutlinedTextField(
                    value = if (draft.isLocked && draft.sshPassword.isNotBlank()) "••••••••" else draft.sshPassword,
                    onValueChange = { v -> onUpdateDraft { it.copy(sshPassword = v) } },
                    label = { Text("Password") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    visualTransformation = if (showPassword && !draft.isLocked) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = onTogglePassword) {
                            Icon(
                                if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = "Tampilkan password"
                            )
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("editor_ssh_pass_input")
                )
            }

            if (draft.protocol != TunnelProtocol.SSH_DIRECT) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = draft.proxyHost,
                        onValueChange = { v -> onUpdateDraft { it.copy(proxyHost = v) } },
                        label = { Text("Remote Proxy / WS Host") },
                        placeholder = { Text("Opsional") },
                        enabled = !draft.isLocked,
                        singleLine = true,
                        modifier = Modifier.weight(2f)
                    )
                    OutlinedTextField(
                        value = draft.proxyPort.toString(),
                        onValueChange = { v ->
                            val p = v.filter { it.isDigit() }.toIntOrNull() ?: 8080
                            onUpdateDraft { it.copy(proxyPort = p) }
                        },
                        label = { Text("Port") },
                        enabled = !draft.isLocked,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (draft.protocol.usesSni) {
                OutlinedTextField(
                    value = draft.sniHost,
                    onValueChange = { v -> onUpdateDraft { it.copy(sniHost = v) } },
                    label = { Text("SNI / Bug Host (SSL/TLS)") },
                    placeholder = { Text("contoh: bug.domain.com") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_sni_input")
                )
            }
        }
    }
}

@Composable
private fun PayloadEditorSection(
    draft: TunnelProfile,
    onUpdateDraft: ((TunnelProfile) -> TunnelProfile) -> Unit,
    onOpenPayloadGenerator: () -> Unit,
    onAppendTag: (String) -> Unit
) {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("HTTP / WebSocket Payload", style = MaterialTheme.typography.titleMedium)
                OutlinedButton(
                    onClick = onOpenPayloadGenerator,
                    enabled = !draft.isLocked,
                    modifier = Modifier.testTag("editor_open_payload_gen_button")
                ) {
                    Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Generator")
                }
            }

            OutlinedTextField(
                value = if (draft.isLocked) "[PAYLOAD TERKUNCI]" else draft.payload,
                onValueChange = { v -> onUpdateDraft { it.copy(payload = v) } },
                enabled = !draft.isLocked,
                textStyle = MonoCodeStyle,
                minLines = 4,
                maxLines = 8,
                label = { Text("Template Payload") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("editor_payload_input")
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PayloadGenerator.quickTags.forEach { tag ->
                    AssistChip(
                        onClick = { onAppendTag(tag) },
                        enabled = !draft.isLocked,
                        label = { Text(tag, style = MonoCodeStyle) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun V2RayAccountSection(
    draft: TunnelProfile,
    onUpdateDraft: ((TunnelProfile) -> TunnelProfile) -> Unit,
    onOpenImportPaste: () -> Unit
) {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Konfigurasi ${draft.protocol.shortBadge}", style = MaterialTheme.typography.titleMedium)
                OutlinedButton(
                    onClick = onOpenImportPaste,
                    modifier = Modifier.testTag("editor_paste_uri_button")
                ) {
                    Icon(Icons.Rounded.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Tempel URI")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = draft.v2rayAddress,
                    onValueChange = { v -> onUpdateDraft { it.copy(v2rayAddress = v) } },
                    label = { Text("Alamat Server") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    modifier = Modifier
                        .weight(2f)
                        .testTag("editor_v2ray_address_input")
                )
                OutlinedTextField(
                    value = draft.v2rayPort.toString(),
                    onValueChange = { v ->
                        val p = v.filter { it.isDigit() }.toIntOrNull() ?: 443
                        onUpdateDraft { it.copy(v2rayPort = p) }
                    },
                    label = { Text("Port") },
                    enabled = !draft.isLocked,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            val credLabel = when (draft.protocol) {
                TunnelProtocol.V2RAY_TROJAN -> "Password Trojan"
                TunnelProtocol.V2RAY_SHADOWSOCKS -> "Password Shadowsocks"
                else -> "UUID"
            }

            OutlinedTextField(
                value = if (draft.isLocked) "••••••••-••••-••••" else draft.v2rayUuid,
                onValueChange = { v -> onUpdateDraft { it.copy(v2rayUuid = v) } },
                label = { Text(credLabel) },
                enabled = !draft.isLocked,
                textStyle = MonoCodeStyle,
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("editor_v2ray_uuid_input")
            )

            if (draft.protocol == TunnelProtocol.V2RAY_SHADOWSOCKS) {
                OutlinedTextField(
                    value = draft.v2raySecurityMethod,
                    onValueChange = { v -> onUpdateDraft { it.copy(v2raySecurityMethod = v) } },
                    label = { Text("Cipher (mis. aes-256-gcm, aes-128-gcm)") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text("Transport Network", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    V2RayTransport.entries.forEach { t ->
                        FilterChip(
                            selected = draft.v2rayTransport == t,
                            enabled = !draft.isLocked,
                            onClick = { onUpdateDraft { it.copy(v2rayTransport = t) } },
                            label = { Text(t.label) }
                        )
                    }
                }

                Text("Keamanan (TLS)", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    V2RaySecurity.entries.forEach { sec ->
                        FilterChip(
                            selected = draft.v2raySecurity == sec,
                            enabled = !draft.isLocked,
                            onClick = { onUpdateDraft { it.copy(v2raySecurity = sec) } },
                            label = { Text(sec.label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = draft.v2raySni,
                    onValueChange = { v -> onUpdateDraft { it.copy(v2raySni = v) } },
                    label = { Text("SNI / Server Name") },
                    enabled = !draft.isLocked,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (draft.v2rayTransport == V2RayTransport.WS) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = draft.v2rayWsHost,
                            onValueChange = { v -> onUpdateDraft { it.copy(v2rayWsHost = v) } },
                            label = { Text("WS Host") },
                            enabled = !draft.isLocked,
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = draft.v2rayWsPath,
                            onValueChange = { v -> onUpdateDraft { it.copy(v2rayWsPath = v) } },
                            label = { Text("WS Path") },
                            enabled = !draft.isLocked,
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HandshakeResultCard(result: HandshakeTestResult) {
    val container = if (result.success) {
        MaterialTheme.colorScheme.tertiaryContainer
    } else {
        MaterialTheme.colorScheme.errorContainer
    }
    val content = if (result.success) {
        MaterialTheme.colorScheme.onTertiaryContainer
    } else {
        MaterialTheme.colorScheme.onErrorContainer
    }

    Surface(
        color = container,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(result.summary, style = MaterialTheme.typography.titleMedium, color = content)
            Text(result.serverResponse, style = MonoCodeStyle, color = content)
        }
    }
}
