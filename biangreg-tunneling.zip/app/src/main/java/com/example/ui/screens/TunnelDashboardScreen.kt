package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppSettings
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelTelemetry
import com.example.data.model.VpnConnectionState
import com.example.ui.theme.AmberConnect
import com.example.ui.theme.MonoCodeStyle
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun TunnelDashboardScreen(
    telemetry: TunnelTelemetry,
    activeProfile: TunnelProfile?,
    settings: AppSettings,
    isProbing: Boolean,
    onToggleConnection: () -> Unit,
    onProbeLatency: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenConfigs: () -> Unit,
    onOpenImport: () -> Unit,
    onOpenExport: () -> Unit,
    onOpenDnsSettings: () -> Unit
) {
    var elapsedSec by remember(telemetry.connectedSinceMs, telemetry.status) { mutableLongStateOf(0L) }
    LaunchedEffect(telemetry.connectedSinceMs, telemetry.status) {
        val since = telemetry.connectedSinceMs
        if (telemetry.status == VpnConnectionState.CONNECTED && since != null) {
            while (true) {
                elapsedSec = ((System.currentTimeMillis() - since) / 1000L).coerceAtLeast(0L)
                delay(1000L)
            }
        } else {
            elapsedSec = 0L
        }
    }

    val accentColor = when (telemetry.status) {
        VpnConnectionState.CONNECTED -> MaterialTheme.colorScheme.tertiary
        VpnConnectionState.CONNECTING,
        VpnConnectionState.DISCONNECTING -> AmberConnect
        VpnConnectionState.ERROR -> MaterialTheme.colorScheme.error
        VpnConnectionState.DISCONNECTED -> MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                DashboardHeader(
                    onOpenImport = onOpenImport,
                    onOpenExport = onOpenExport,
                    onOpenSettings = onOpenDnsSettings
                )
            }

            item {
                HeroReactorCard(
                    telemetry = telemetry,
                    activeProfile = activeProfile,
                    elapsedSec = elapsedSec,
                    accentColor = accentColor,
                    onToggleConnection = onToggleConnection
                )
            }

            item {
                TrafficTelemetryCard(telemetry = telemetry)
            }

            item {
                ActiveProfileCard(
                    activeProfile = activeProfile,
                    onEdit = onOpenEditor,
                    onSwitch = onOpenConfigs
                )
            }

            item {
                QuickDiagnosticsRow(
                    settings = settings,
                    latencyMs = telemetry.lastLatencyMs ?: activeProfile?.lastLatencyMs,
                    isProbing = isProbing,
                    onProbeLatency = onProbeLatency,
                    onOpenDnsSettings = onOpenDnsSettings
                )
            }
        }
    }
}

@Composable
private fun DashboardHeader(
    onOpenImport: () -> Unit,
    onOpenExport: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_tunnel_emblem),
                contentDescription = "Logo BianGreg Tunneling",
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
            )
            Column {
                Text(
                    text = "BianGreg Tunneling",
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "SSH Payload & V2Ray Client",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilledTonalIconButton(
                onClick = onOpenImport,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("dashboard_import_button")
            ) {
                Icon(Icons.Rounded.Download, contentDescription = "Import Config")
            }
            FilledTonalIconButton(
                onClick = onOpenExport,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("dashboard_export_button")
            ) {
                Icon(Icons.Rounded.Upload, contentDescription = "Export Config")
            }
            FilledTonalIconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("dashboard_settings_button")
            ) {
                Icon(Icons.Rounded.Dns, contentDescription = "Pengaturan DNS & Tunnel")
            }
        }
    }
}

@Composable
private fun HeroReactorCard(
    telemetry: TunnelTelemetry,
    activeProfile: TunnelProfile?,
    elapsedSec: Long,
    accentColor: Color,
    onToggleConnection: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactor_pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_value"
    )

    val isBusy = telemetry.status == VpnConnectionState.CONNECTING ||
        telemetry.status == VpnConnectionState.DISCONNECTING
    val isConnected = telemetry.status == VpnConnectionState.CONNECTED

    val statusLabel = when (telemetry.status) {
        VpnConnectionState.DISCONNECTED -> "TERPUTUS"
        VpnConnectionState.CONNECTING -> "MENGHUBUNGKAN..."
        VpnConnectionState.CONNECTED -> "TERHUBUNG"
        VpnConnectionState.DISCONNECTING -> "MEMUTUSKAN..."
        VpnConnectionState.ERROR -> "KONEKSI GAGAL"
    }

    val surfaceBrush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surfaceContainer,
            MaterialTheme.colorScheme.surfaceContainerLow
        )
    )

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(surfaceBrush)
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = accentColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = statusLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = accentColor,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Text(
                    text = if (isConnected) formatDuration(elapsedSec) else "00:00:00",
                    style = MonoCodeStyle.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
            }

            Box(
                modifier = Modifier.size(164.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val baseRadius = size.minDimension * 0.34f
                    drawCircle(
                        color = accentColor.copy(alpha = 0.18f),
                        radius = baseRadius + 14.dp.toPx(),
                        center = center,
                        style = Stroke(width = 2.dp.toPx())
                    )
                    if (isConnected || isBusy) {
                        val ringRadius = baseRadius + (size.minDimension * 0.16f) * pulse
                        drawCircle(
                            color = accentColor.copy(alpha = (1f - pulse) * 0.55f),
                            radius = ringRadius,
                            center = center,
                            style = Stroke(width = 2.5.dp.toPx())
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = if (isConnected) accentColor else MaterialTheme.colorScheme.surfaceContainerHigh,
                    shadowElevation = 8.dp,
                    border = BorderStroke(2.dp, accentColor),
                    modifier = Modifier
                        .size(108.dp)
                        .clip(CircleShape)
                        .minimumInteractiveComponentSize()
                        .clickable(onClick = onToggleConnection)
                        .testTag("vpn_connect_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isBusy) {
                            CircularProgressIndicator(
                                color = accentColor,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(40.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.PowerSettingsNew,
                                contentDescription = if (isConnected) "Putuskan VPN" else "Hubungkan VPN",
                                tint = if (isConnected) MaterialTheme.colorScheme.onTertiary else accentColor,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = activeProfile?.name ?: "Belum Ada Profil Aktif",
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = activeProfile?.let {
                        "${it.protocol.displayName} • ${it.endpointSummary()}"
                    } ?: "Buat atau import config SSH/V2Ray untuk mulai",
                    style = MonoCodeStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            AnimatedVisibility(visible = !telemetry.errorMessage.isNullOrBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = telemetry.errorMessage.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Button(
                onClick = onToggleConnection,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isConnected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    contentColor = if (isConnected) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("vpn_primary_action_button")
            ) {
                Text(
                    text = when {
                        isConnected -> "PUTUSKAN TUNNEL"
                        isBusy -> "BATALKAN / PUTUSKAN"
                        else -> "HUBUNGKAN VPN"
                    },
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun TrafficTelemetryCard(telemetry: TunnelTelemetry) {
    val upColor = MaterialTheme.colorScheme.primary
    val downColor = MaterialTheme.colorScheme.tertiary

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatMetricItem(
                    icon = Icons.Rounded.ArrowUpward,
                    label = "Upload",
                    speed = "${formatBytes(telemetry.speedUpBps)}/s",
                    total = formatBytes(telemetry.bytesUp),
                    tint = upColor
                )
                StatMetricItem(
                    icon = Icons.Rounded.ArrowDownward,
                    label = "Download",
                    speed = "${formatBytes(telemetry.speedDownBps)}/s",
                    total = formatBytes(telemetry.bytesDown),
                    tint = downColor
                )
            }

            TrafficSparkline(
                upPoints = telemetry.speedHistoryUp,
                downPoints = telemetry.speedHistoryDown,
                upColor = upColor,
                downColor = downColor,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            )
        }
    }
}

@Composable
private fun StatMetricItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    speed: String,
    total: String,
    tint: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            color = tint.copy(alpha = 0.14f),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier
                    .padding(8.dp)
                    .size(18.dp)
            )
        }
        Column {
            Text(
                text = "$label • $total",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = speed,
                style = MonoCodeStyle.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun TrafficSparkline(
    upPoints: List<Long>,
    downPoints: List<Long>,
    upColor: Color,
    downColor: Color,
    modifier: Modifier = Modifier
) {
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier = modifier) {
        val maxVal = maxOf(
            upPoints.maxOrNull() ?: 0L,
            downPoints.maxOrNull() ?: 0L,
            1024L
        ).toFloat()

        drawLine(
            color = gridColor.copy(alpha = 0.5f),
            start = Offset(0f, size.height),
            end = Offset(size.width, size.height),
            strokeWidth = 1.dp.toPx()
        )

        fun drawSeries(points: List<Long>, color: Color) {
            if (points.size < 2) return
            val path = Path()
            val stepX = size.width / (points.size - 1).coerceAtLeast(1)
            points.forEachIndexed { index, value ->
                val x = index * stepX
                val ratio = (value.toFloat() / maxVal).coerceIn(0f, 1f)
                val y = size.height - (ratio * (size.height - 4.dp.toPx())) - 2.dp.toPx()
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(
                path = path,
                color = color,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        drawSeries(upPoints, upColor)
        drawSeries(downPoints, downColor)
    }
}

@Composable
private fun ActiveProfileCard(
    activeProfile: TunnelProfile?,
    onEdit: () -> Unit,
    onSwitch: () -> Unit
) {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Profil Terpilih",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                if (activeProfile != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (activeProfile.isLocked) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = "Config terkunci",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = activeProfile.protocol.shortBadge,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            if (activeProfile != null) {
                Text(
                    text = activeProfile.name,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = buildString {
                        append("Server: ${activeProfile.endpointSummary()}")
                        if (!activeProfile.protocol.isV2Ray && activeProfile.proxyHost.isNotBlank()) {
                            append(" | Proxy: ${activeProfile.proxyHost}:${activeProfile.proxyPort}")
                        }
                        val sni = if (activeProfile.protocol.isV2Ray) activeProfile.v2raySni else activeProfile.sniHost
                        if (sni.isNotBlank()) append(" | SNI: $sni")
                    },
                    style = MonoCodeStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            } else {
                Text(
                    text = "Belum ada config tersimpan. Tekan Kelola Config untuk buat baru atau import.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("dashboard_edit_profile_button")
                ) {
                    Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Edit Payload")
                }
                FilledTonalButton(
                    onClick = onSwitch,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("dashboard_switch_profile_button")
                ) {
                    Icon(Icons.Rounded.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Daftar Config")
                }
            }
        }
    }
}

@Composable
private fun QuickDiagnosticsRow(
    settings: AppSettings,
    latencyMs: Long?,
    isProbing: Boolean,
    onProbeLatency: () -> Unit,
    onOpenDnsSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedCard(
            onClick = onProbeLatency,
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("dashboard_ping_card"),
            shape = MaterialTheme.shapes.medium,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (isProbing) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(
                        Icons.Rounded.Speed,
                        contentDescription = "Cek Ping",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Column {
                    Text("Latency TCP", style = MaterialTheme.typography.labelMedium)
                    Text(
                        text = latencyMs?.let { "$it ms" } ?: "Tap untuk cek",
                        style = MonoCodeStyle.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }

        OutlinedCard(
            onClick = onOpenDnsSettings,
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("dashboard_dns_card"),
            shape = MaterialTheme.shapes.medium,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    Icons.Rounded.Dns,
                    contentDescription = "DNS",
                    tint = MaterialTheme.colorScheme.secondary
                )
                Column {
                    Text("DNS Tunnel", style = MaterialTheme.typography.labelMedium)
                    Text(
                        text = settings.dnsPrimary,
                        style = MonoCodeStyle.copy(fontWeight = FontWeight.SemiBold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

private fun formatDuration(totalSec: Long): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0))
        else -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }
}
