package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber-Tactical Dark Palette
val ObsidianBg = Color(0xFF090E17)
val SlateSurface = Color(0xFF101827)
val SlateCard = Color(0xFF162135)
val SlateElevated = Color(0xFF1F2D45)
val SlateOutline = Color(0xFF2B3D5B)

val ElectricCyan = Color(0xFF00E5FF)
val CyanDeep = Color(0xFF003640)
val CyanMuted = Color(0xFF7BEFFF)

val EmeraldSignal = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF063729)
val AmberConnect = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF3E2604)
val CoralAlert = Color(0xFFEF4444)
val CoralContainer = Color(0xFF451214)
val IndigoAccent = Color(0xFF818CF8)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)

// Clean Tactical Light Palette
val LightBg = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE7EEF8)
val LightOutline = Color(0xFFC5D2E6)
val CyanPrimaryLight = Color(0xFF00677F)
val CyanContainerLight = Color(0xFFC4F1FF)
val IndigoLight = Color(0xFF4338CA)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
