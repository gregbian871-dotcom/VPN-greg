package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.LogLevel
import com.example.data.model.TunnelProfile
import com.example.data.repository.TunnelRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class BianGregVpnService : VpnService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var connectJob: Job? = null
    private var telemetryJob: Job? = null

    private var tunInterface: ParcelFileDescriptor? = null
    private var sshManager: SshTunnelManager? = null
    private var v2RayManager: V2RayTunnelManager? = null
    private var packetEngine: TunPacketEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                disconnectTunnel(reason = "Diputuskan oleh pengguna.")
                return START_NOT_STICKY
            }

            ACTION_CONNECT -> {
                val profileId = intent.getStringExtra(EXTRA_PROFILE_ID)
                if (profileId.isNullOrBlank()) {
                    VpnStateHolder.log(LogLevel.ERR, "Profil VPN tidak ditemukan.")
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundCompat("Menghubungkan tunnel...")
                startTunnel(profileId)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startTunnel(profileId: String) {
        connectJob?.cancel()
        teardownActiveResources()

        connectJob = serviceScope.launch {
            val repo = TunnelRepository(
                context = applicationContext,
                dao = AppDatabase.getInstance(applicationContext).tunnelProfileDao()
            )
            val profile = repo.getProfileById(profileId)
            if (profile == null) {
                VpnStateHolder.log(LogLevel.ERR, "Profil dengan ID $profileId tidak ditemukan di database.")
                VpnStateHolder.setDisconnected("Profil tidak ditemukan")
                stopForegroundCompat()
                stopSelf()
                return@launch
            }

            val settings = repo.getCurrentSettings()
            VpnStateHolder.setConnecting(profile)
            VpnStateHolder.log(
                LogLevel.INFO,
                "Memulai ${profile.name} (${profile.protocol.displayName})..."
            )

            try {
                if (settings.wakeLockEnabled) {
                    acquireWakeLock()
                }

                val latencyStart = System.nanoTime()
                val socksPort = if (profile.protocol.isV2Ray) {
                    val mgr = V2RayTunnelManager(this@BianGregVpnService, profile)
                    v2RayManager = mgr
                    mgr.start()
                } else {
                    val mgr = SshTunnelManager(this@BianGregVpnService, profile)
                    sshManager = mgr
                    mgr.start()
                }
                val connectLatencyMs = ((System.nanoTime() - latencyStart) / 1_000_000L).coerceAtLeast(1L)
                repo.updateLatency(profile.id, connectLatencyMs)

                val pfd = establishTunInterface(profile, settings.dnsPrimary, settings.dnsSecondary)
                tunInterface = pfd
                VpnStateHolder.log(
                    LogLevel.INFO,
                    "Interface TUN aktif (10.88.0.2/32 | DNS ${settings.dnsPrimary}, ${settings.dnsSecondary})"
                )

                val engine = TunPacketEngine(
                    vpnService = this@BianGregVpnService,
                    tunFd = pfd,
                    socksPort = socksPort,
                    dnsPrimary = settings.dnsPrimary
                )
                packetEngine = engine
                engine.start()

                VpnStateHolder.setConnected(profile, connectLatencyMs)
                updateNotification("Terhubung: ${profile.name} (${profile.protocol.shortBadge})")
                startTelemetryLoop()
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                VpnStateHolder.log(LogLevel.ERR, "Koneksi gagal: $msg")
                teardownActiveResources()
                VpnStateHolder.setDisconnected(error = msg)
                stopForegroundCompat()
                stopSelf()
            }
        }
    }

    private fun establishTunInterface(
        profile: TunnelProfile,
        dnsPrimary: String,
        dnsSecondary: String
    ): ParcelFileDescriptor {
        val builder = Builder()
            .setSession("BianGreg Tunneling - ${profile.name}")
            .setMtu(1500)
            .addAddress("10.88.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(dnsPrimary)
            .addDnsServer(dnsSecondary)

        runCatching {
            builder.addDisallowedApplication(packageName)
        }

        return builder.establish()
            ?: throw IllegalStateException("Gagal membuat interface TUN VPN (izin belum diberikan)")
    }

    private fun startTelemetryLoop() {
        telemetryJob?.cancel()
        telemetryJob = serviceScope.launch {
            var prevUp = 0L
            var prevDown = 0L
            while (isActive) {
                delay(1000L)
                val up = (sshManager?.totalBytesUp ?: v2RayManager?.totalBytesUp ?: 0L) +
                    (packetEngine?.directBytesUp?.get() ?: 0L)
                val down = (sshManager?.totalBytesDown ?: v2RayManager?.totalBytesDown ?: 0L) +
                    (packetEngine?.directBytesDown?.get() ?: 0L)
                val speedUp = (up - prevUp).coerceAtLeast(0L)
                val speedDown = (down - prevDown).coerceAtLeast(0L)
                prevUp = up
                prevDown = down
                VpnStateHolder.updateTrafficSample(up, down, speedUp, speedDown)
            }
        }
    }

    private fun disconnectTunnel(reason: String) {
        VpnStateHolder.setDisconnecting()
        VpnStateHolder.log(LogLevel.INFO, reason)
        connectJob?.cancel()
        teardownActiveResources()
        VpnStateHolder.setDisconnected()
        stopForegroundCompat()
        stopSelf()
    }

    private fun teardownActiveResources() {
        telemetryJob?.cancel()
        telemetryJob = null
        runCatching { packetEngine?.close() }
        packetEngine = null
        runCatching { sshManager?.close() }
        sshManager = null
        runCatching { v2RayManager?.close() }
        v2RayManager = null
        runCatching { tunInterface?.close() }
        tunInterface = null
        releaseWakeLock()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BianGregTunneling::VpnLock").apply {
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        wakeLock = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_notification_channel_desc)
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BianGregVpnService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tunnel_emblem)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(statusText)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .addAction(0, "Putuskan", disconnectIntent)
            .build()
    }

    private fun startForegroundCompat(statusText: String) {
        val notification = buildNotification(statusText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(statusText: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(statusText))
    }

    private fun stopForegroundCompat() {
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onRevoke() {
        disconnectTunnel("Izin VPN dicabut oleh sistem.")
        super.onRevoke()
    }

    override fun onDestroy() {
        teardownActiveResources()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_CONNECT = "com.example.vpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.example.vpn.ACTION_DISCONNECT"
        const val EXTRA_PROFILE_ID = "extra_profile_id"
        private const val CHANNEL_ID = "biangreg_vpn_channel"
        private const val NOTIFICATION_ID = 7071

        fun startConnect(context: Context, profileId: String) {
            val intent = Intent(context, BianGregVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_PROFILE_ID, profileId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopTunnel(context: Context) {
            val intent = Intent(context, BianGregVpnService::class.java).apply {
                action = ACTION_DISCONNECT
            }
            context.startService(intent)
        }
    }
}
