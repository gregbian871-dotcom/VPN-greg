package com.example.vpn

import com.example.data.model.LogLevel
import java.io.Closeable
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

interface UpstreamStream : Closeable {
    val input: InputStream
    val output: OutputStream
}

typealias SocksBridgeOpener = (targetHost: String, targetPort: Int) -> UpstreamStream

class LocalSocks5Server(
    private val opener: SocksBridgeOpener
) : Closeable {

    private val running = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool()
    private var serverSocket: ServerSocket? = null

    val totalBytesUp = AtomicLong(0L)
    val totalBytesDown = AtomicLong(0L)

    val port: Int
        get() = serverSocket?.localPort ?: -1

    fun start(): Int {
        if (running.getAndSet(true)) return port
        val server = ServerSocket(0, 128, InetAddress.getLoopbackAddress())
        serverSocket = server
        executor.execute {
            while (running.get() && !server.isClosed) {
                try {
                    val client = server.accept()
                    executor.execute { handleClient(client) }
                } catch (_: Exception) {
                    if (!running.get()) break
                }
            }
        }
        return server.localPort
    }

    private fun handleClient(client: Socket) {
        client.use { sock ->
            sock.tcpNoDelay = true
            sock.soTimeout = 30_000
            val cin = sock.getInputStream()
            val cout = sock.getOutputStream()

            // 1. Greeting: VER(1) NMETHODS(1) METHODS(N)
            val ver = cin.read()
            if (ver != 0x05) return
            val nMethods = cin.read()
            if (nMethods <= 0) return
            readExact(cin, nMethods)
            // Accept NO AUTHENTICATION REQUIRED (0x00)
            cout.write(byteArrayOf(0x05, 0x00))
            cout.flush()

            // 2. Request: VER(1) CMD(1) RSV(1) ATYP(1)
            val reqVer = cin.read()
            val cmd = cin.read()
            val rsv = cin.read()
            val atyp = cin.read()
            if (reqVer != 0x05 || cmd != 0x01 || rsv < 0 || atyp < 0) {
                cout.write(byteArrayOf(0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                cout.flush()
                return
            }

            val targetHost = when (atyp) {
                0x01 -> {
                    val addr = readExact(cin, 4)
                    InetAddress.getByAddress(addr).hostAddress ?: return
                }
                0x03 -> {
                    val len = cin.read()
                    if (len <= 0) return
                    String(readExact(cin, len), Charsets.UTF_8)
                }
                0x04 -> {
                    val addr = readExact(cin, 16)
                    InetAddress.getByAddress(addr).hostAddress ?: return
                }
                else -> return
            }
            val portBytes = readExact(cin, 2)
            val targetPort = ((portBytes[0].toInt() and 0xFF) shl 8) or (portBytes[1].toInt() and 0xFF)

            val upstream = try {
                opener(targetHost, targetPort)
            } catch (e: Exception) {
                VpnStateHolder.log(LogLevel.WARN, "Gagal buka stream ke $targetHost:$targetPort (${e.message})")
                cout.write(byteArrayOf(0x05, 0x05, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                cout.flush()
                return
            }

            upstream.use { remote ->
                cout.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                cout.flush()
                sock.soTimeout = 0

                val downFuture = executor.submit {
                    relay(remote.input, cout, totalBytesDown)
                }
                relay(cin, remote.output, totalBytesUp)
                try {
                    downFuture.get()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun relay(input: InputStream, output: OutputStream, counter: AtomicLong) {
        val buf = ByteArray(16384)
        try {
            while (running.get()) {
                val read = input.read(buf)
                if (read <= 0) break
                output.write(buf, 0, read)
                output.flush()
                counter.addAndGet(read.toLong())
            }
        } catch (_: Exception) {
        }
    }

    private fun readExact(input: InputStream, len: Int): ByteArray {
        val out = ByteArray(len)
        var off = 0
        while (off < len) {
            val r = input.read(out, off, len - off)
            if (r == -1) throw EOFException("Unexpected EOF in SOCKS5 stream")
            off += r
        }
        return out
    }

    override fun close() {
        running.set(false)
        runCatching { serverSocket?.close() }
        executor.shutdownNow()
    }
}
