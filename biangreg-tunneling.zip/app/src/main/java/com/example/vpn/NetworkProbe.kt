package com.example.vpn

import com.example.data.codec.PayloadGenerator
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.model.V2RaySecurity
import com.example.data.model.V2RayTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

data class HandshakeTestResult(
    val success: Boolean,
    val latencyMs: Long,
    val summary: String,
    val serverResponse: String
)

object NetworkProbe {

    suspend fun probeTcpLatency(host: String, port: Int, timeoutMs: Int = 5000): Result<Long> =
        withContext(Dispatchers.IO) {
            runCatching {
                val start = System.nanoTime()
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host.trim(), port), timeoutMs)
                }
                ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
            }
        }

    suspend fun testHandshake(profile: TunnelProfile): HandshakeTestResult =
        withContext(Dispatchers.IO) {
            val startNs = System.nanoTime()
            runCatching {
                when (profile.protocol) {
                    TunnelProtocol.SSH_DIRECT -> {
                        Socket().use { socket ->
                            socket.soTimeout = 6000
                            socket.connect(
                                InetSocketAddress(profile.sshHost.trim(), profile.sshPort),
                                6000
                            )
                            val banner = socket.getInputStream().bufferedReader().readLine()
                                ?: "(Tidak ada banner SSH)"
                            val rtt = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                            HandshakeTestResult(
                                success = banner.startsWith("SSH-"),
                                latencyMs = rtt,
                                summary = "Banner SSH diterima (${rtt} ms)",
                                serverResponse = banner
                            )
                        }
                    }

                    TunnelProtocol.SSH_PAYLOAD -> {
                        val connectHost = profile.proxyHost.ifBlank { profile.sshHost }.trim()
                        val connectPort = if (profile.proxyHost.isNotBlank()) profile.proxyPort else profile.sshPort
                        Socket().use { socket ->
                            socket.soTimeout = 7000
                            socket.connect(InetSocketAddress(connectHost, connectPort), 7000)
                            val chunks = PayloadGenerator.buildWireChunks(
                                template = profile.payload,
                                targetHost = profile.sshHost.trim(),
                                targetPort = profile.sshPort,
                                fallbackHost = connectHost
                            )
                            val out = socket.getOutputStream()
                            for (chunk in chunks) {
                                if (chunk.delayBeforeMs > 0) Thread.sleep(chunk.delayBeforeMs)
                                out.write(chunk.bytes)
                                out.flush()
                            }
                            val response = readHttpResponseHeader(BufferedInputStream(socket.getInputStream()))
                            val rtt = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                            val firstLine = response.lineSequence().firstOrNull().orEmpty()
                            val ok = firstLine.contains("101") ||
                                firstLine.contains("200") ||
                                firstLine.startsWith("SSH-")
                            HandshakeTestResult(
                                success = ok,
                                latencyMs = rtt,
                                summary = if (ok) "Payload OK ($firstLine)" else "Respons server: $firstLine",
                                serverResponse = response.ifBlank { "(Respons kosong / timeout baca header)" }
                            )
                        }
                    }

                    TunnelProtocol.SSH_SSL_SNI,
                    TunnelProtocol.SSH_WEBSOCKET -> {
                        val connectHost = profile.proxyHost.ifBlank { profile.sshHost }.trim()
                        val connectPort = if (profile.proxyHost.isNotBlank()) profile.proxyPort else profile.sshPort
                        val sni = profile.sniHost.ifBlank { connectHost }.trim()
                        val useTls = profile.protocol == TunnelProtocol.SSH_SSL_SNI ||
                            profile.sniHost.isNotBlank() ||
                            connectPort == 443 ||
                            connectPort == 8443

                        Socket().use { raw ->
                            raw.soTimeout = 7000
                            raw.connect(InetSocketAddress(connectHost, connectPort), 7000)
                            val activeSocket: Socket = if (useTls) {
                                val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
                                (sslFactory.createSocket(raw, connectHost, connectPort, true) as SSLSocket).apply {
                                    val params = sslParameters
                                    params.serverNames = listOf(SNIHostName(sni))
                                    sslParameters = params
                                    startHandshake()
                                }
                            } else {
                                raw
                            }

                            val tlsInfo = if (activeSocket is SSLSocket) {
                                "TLS: ${activeSocket.session.protocol} | ${activeSocket.session.cipherSuite}\nSNI: $sni"
                            } else {
                                "Plain TCP: $connectHost:$connectPort"
                            }

                            var payloadResp = ""
                            if (profile.payload.isNotBlank() && profile.protocol == TunnelProtocol.SSH_WEBSOCKET) {
                                val chunks = PayloadGenerator.buildWireChunks(
                                    template = profile.payload,
                                    targetHost = profile.sshHost.trim(),
                                    targetPort = profile.sshPort,
                                    fallbackHost = sni
                                )
                                val out = activeSocket.getOutputStream()
                                for (chunk in chunks) {
                                    if (chunk.delayBeforeMs > 0) Thread.sleep(chunk.delayBeforeMs)
                                    out.write(chunk.bytes)
                                    out.flush()
                                }
                                payloadResp = readHttpResponseHeader(BufferedInputStream(activeSocket.getInputStream()))
                            }
                            val rtt = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                            HandshakeTestResult(
                                success = true,
                                latencyMs = rtt,
                                summary = "Handshake berhasil (${rtt} ms)",
                                serverResponse = listOf(tlsInfo, payloadResp).filter { it.isNotBlank() }.joinToString("\n\n")
                            )
                        }
                    }

                    else -> {
                        val host = profile.v2rayAddress.trim()
                        val port = profile.v2rayPort
                        val sni = profile.v2raySni.ifBlank { profile.v2rayWsHost.ifBlank { host } }.trim()
                        Socket().use { raw ->
                            raw.soTimeout = 7000
                            raw.connect(InetSocketAddress(host, port), 7000)
                            val activeSocket: Socket = if (profile.v2raySecurity != V2RaySecurity.NONE) {
                                val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
                                (sslFactory.createSocket(raw, host, port, true) as SSLSocket).apply {
                                    if (sni.isNotBlank()) {
                                        val params = sslParameters
                                        params.serverNames = listOf(SNIHostName(sni))
                                        sslParameters = params
                                    }
                                    startHandshake()
                                }
                            } else {
                                raw
                            }

                            val details = StringBuilder()
                            if (activeSocket is SSLSocket) {
                                details.appendLine("TLS: ${activeSocket.session.protocol} (${activeSocket.session.cipherSuite})")
                            } else {
                                details.appendLine("TCP Terhubung: $host:$port")
                            }

                            if (profile.v2rayTransport == V2RayTransport.WS) {
                                val wsHost = profile.v2rayWsHost.ifBlank { sni.ifBlank { host } }
                                val path = profile.v2rayWsPath.ifBlank { "/" }
                                val key = java.util.Base64.getEncoder()
                                    .encodeToString(ByteArray(16) { (it + 1).toByte() })
                                val upgradeReq = buildString {
                                    append("GET $path HTTP/1.1\r\n")
                                    append("Host: $wsHost\r\n")
                                    append("Upgrade: websocket\r\n")
                                    append("Connection: Upgrade\r\n")
                                    append("Sec-WebSocket-Key: $key\r\n")
                                    append("Sec-WebSocket-Version: 13\r\n\r\n")
                                }
                                activeSocket.getOutputStream().apply {
                                    write(upgradeReq.toByteArray(Charsets.UTF_8))
                                    flush()
                                }
                                val wsResp = readHttpResponseHeader(BufferedInputStream(activeSocket.getInputStream()))
                                details.append(wsResp.ifBlank { "(WebSocket upgrade tanpa respons teks)" })
                            }

                            val rtt = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                            HandshakeTestResult(
                                success = true,
                                latencyMs = rtt,
                                summary = "${profile.protocol.shortBadge} Handshake OK (${rtt} ms)",
                                serverResponse = details.toString().trim()
                            )
                        }
                    }
                }
            }.getOrElse { err ->
                val rtt = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                HandshakeTestResult(
                    success = false,
                    latencyMs = rtt,
                    summary = "Handshake gagal: ${err.message ?: err.javaClass.simpleName}",
                    serverResponse = err.stackTraceToString().lineSequence().take(6).joinToString("\n")
                )
            }
        }

    fun readHttpResponseHeader(input: BufferedInputStream, maxBytes: Int = 8192): String {
        val buf = ByteArray(maxBytes)
        var total = 0
        while (total < maxBytes) {
            val b = input.read()
            if (b == -1) break
            buf[total++] = b.toByte()
            if (total >= 4 &&
                buf[total - 4] == '\r'.code.toByte() &&
                buf[total - 3] == '\n'.code.toByte() &&
                buf[total - 2] == '\r'.code.toByte() &&
                buf[total - 1] == '\n'.code.toByte()
            ) {
                break
            }
            if (total == 4 && String(buf, 0, 4, Charsets.UTF_8) == "SSH-") {
                // Direct SSH banner fallback
                while (total < maxBytes) {
                    val nb = input.read()
                    if (nb == -1 || nb == '\n'.code) break
                    buf[total++] = nb.toByte()
                }
                break
            }
        }
        return String(buf, 0, total, Charsets.UTF_8).trim()
    }
}
