package com.example.vpn

import android.net.VpnService
import com.example.data.codec.PayloadGenerator
import com.example.data.model.LogLevel
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.jcraft.jsch.SocketFactory
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class PayloadSocketFactory(
    private val vpnService: VpnService?,
    private val profile: TunnelProfile
) : SocketFactory {

    override fun createSocket(host: String, port: Int): Socket {
        val sshHost = profile.sshHost.ifBlank { host }.trim()
        val sshPort = if (profile.sshPort in 1..65535) profile.sshPort else port

        return when (profile.protocol) {
            TunnelProtocol.SSH_DIRECT -> {
                val socket = createProtectedTcpSocket(sshHost, sshPort)
                VpnStateHolder.log(LogLevel.NET, "TCP Direct terhubung ke $sshHost:$sshPort")
                socket
            }

            TunnelProtocol.SSH_PAYLOAD -> {
                val targetHost = profile.proxyHost.ifBlank { sshHost }.trim()
                val targetPort = if (profile.proxyHost.isNotBlank()) profile.proxyPort else sshPort
                val socket = createProtectedTcpSocket(targetHost, targetPort)
                injectPayloadAndReadResponse(socket, sshHost, sshPort, targetHost)
                socket
            }

            TunnelProtocol.SSH_SSL_SNI -> {
                val targetHost = profile.proxyHost.ifBlank { sshHost }.trim()
                val targetPort = if (profile.proxyHost.isNotBlank()) profile.proxyPort else sshPort
                val sni = profile.sniHost.ifBlank { targetHost }.trim()
                val raw = createProtectedTcpSocket(targetHost, targetPort)
                val sslSocket = wrapTls(raw, targetHost, targetPort, sni)
                if (profile.payload.isNotBlank() && profile.proxyHost.isNotBlank()) {
                    injectPayloadAndReadResponse(sslSocket, sshHost, sshPort, sni)
                }
                sslSocket
            }

            TunnelProtocol.SSH_WEBSOCKET -> {
                val targetHost = profile.proxyHost.ifBlank { sshHost }.trim()
                val targetPort = if (profile.proxyHost.isNotBlank()) profile.proxyPort else sshPort
                val sni = profile.sniHost.ifBlank { targetHost }.trim()
                val useTls = profile.sniHost.isNotBlank() || targetPort == 443 || targetPort == 8443
                val raw = createProtectedTcpSocket(targetHost, targetPort)
                val activeSocket = if (useTls) {
                    wrapTls(raw, targetHost, targetPort, sni)
                } else {
                    raw
                }
                injectPayloadAndReadResponse(activeSocket, sshHost, sshPort, sni)
                activeSocket
            }

            else -> createProtectedTcpSocket(sshHost, sshPort)
        }
    }

    override fun getInputStream(socket: Socket): InputStream = socket.getInputStream()

    override fun getOutputStream(socket: Socket): OutputStream = socket.getOutputStream()

    private fun createProtectedTcpSocket(host: String, port: Int): Socket {
        val socket = Socket()
        vpnService?.protect(socket)
        socket.tcpNoDelay = true
        socket.soTimeout = 15_000
        socket.connect(InetSocketAddress(host, port), 12_000)
        return socket
    }

    private fun wrapTls(raw: Socket, host: String, port: Int, sni: String): SSLSocket {
        val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
        val sslSocket = sslFactory.createSocket(raw, host, port, true) as SSLSocket
        if (sni.isNotBlank()) {
            val params = sslSocket.sslParameters
            params.serverNames = listOf(SNIHostName(sni))
            sslSocket.sslParameters = params
        }
        sslSocket.startHandshake()
        VpnStateHolder.log(
            LogLevel.NET,
            "SSL/SNI OK ($sni): ${sslSocket.session.protocol} / ${sslSocket.session.cipherSuite}"
        )
        return sslSocket
    }

    private fun injectPayloadAndReadResponse(
        socket: Socket,
        sshHost: String,
        sshPort: Int,
        fallbackHost: String
    ) {
        if (profile.payload.isBlank()) return
        val chunks = PayloadGenerator.buildWireChunks(
            template = profile.payload,
            targetHost = sshHost,
            targetPort = sshPort,
            fallbackHost = fallbackHost
        )
        VpnStateHolder.log(LogLevel.PAYLOAD, "Mengirim ${chunks.size} fragmen payload ke $fallbackHost...")
        val out = socket.getOutputStream()
        for (chunk in chunks) {
            if (chunk.delayBeforeMs > 0) Thread.sleep(chunk.delayBeforeMs)
            out.write(chunk.bytes)
            out.flush()
        }

        val input = socket.getInputStream()
        val buffered = BufferedInputStream(input)
        val header = NetworkProbe.readHttpResponseHeader(buffered)
        val statusLine = header.lineSequence().firstOrNull().orEmpty()
        VpnStateHolder.log(
            LogLevel.NET,
            "Respons payload: ${statusLine.ifBlank { "(tidak ada header HTTP)" }}"
        )
        if (header.startsWith("HTTP/") && !statusLine.contains("101") && !statusLine.contains("200")) {
            throw IOException("Proxy/Payload ditolak server: $statusLine")
        }
    }

    companion object {
        fun connectProtected(vpnService: VpnService?, host: String, port: Int, timeoutMs: Int = 10_000): Socket {
            val socket = Socket()
            vpnService?.protect(socket)
            socket.tcpNoDelay = true
            socket.soTimeout = timeoutMs
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            return socket
        }

        fun wrapProtectedTls(
            raw: Socket,
            host: String,
            port: Int,
            sni: String
        ): SSLSocket {
            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val sslSocket = sslFactory.createSocket(raw, host, port, true) as SSLSocket
            if (sni.isNotBlank()) {
                val params = sslSocket.sslParameters
                params.serverNames = listOf(SNIHostName(sni))
                sslSocket.sslParameters = params
            }
            sslSocket.startHandshake()
            return sslSocket
        }
    }
}
