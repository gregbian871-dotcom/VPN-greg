package com.example.vpn

import android.net.VpnService
import com.example.data.model.LogLevel
import com.example.data.model.TunnelProfile
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.Closeable
import java.io.InputStream
import java.io.OutputStream

class SshTunnelManager(
    private val vpnService: VpnService,
    private val profile: TunnelProfile
) : Closeable {

    private var session: Session? = null
    private var socksServer: LocalSocks5Server? = null

    val localSocksPort: Int
        get() = socksServer?.port ?: -1

    val totalBytesUp: Long
        get() = socksServer?.totalBytesUp?.get() ?: 0L

    val totalBytesDown: Long
        get() = socksServer?.totalBytesDown?.get() ?: 0L

    fun start(): Int {
        val jsch = JSch()
        if (profile.sshPrivateKey.isNotBlank()) {
            jsch.addIdentity(
                "biangreg_key",
                profile.sshPrivateKey.toByteArray(Charsets.UTF_8),
                null,
                null
            )
        }

        val sshSession = jsch.getSession(
            profile.sshUsername.trim(),
            profile.sshHost.trim(),
            profile.sshPort
        ).apply {
            if (profile.sshPassword.isNotBlank()) {
                setPassword(profile.sshPassword)
            }
            setConfig("StrictHostKeyChecking", "no")
            setConfig("PreferredAuthentications", "publickey,password,keyboard-interactive")
            setSocketFactory(PayloadSocketFactory(vpnService, profile))
            setServerAliveInterval(25_000)
            setServerAliveCountMax(3)
        }

        VpnStateHolder.log(
            LogLevel.INFO,
            "Menghubungkan SSH2 ke ${profile.sshHost}:${profile.sshPort}..."
        )
        sshSession.connect(15_000)
        session = sshSession
        VpnStateHolder.log(
            LogLevel.NET,
            "SSH2 terautentikasi! Server: ${sshSession.serverVersion}"
        )

        val server = LocalSocks5Server { targetHost, targetPort ->
            val active = session ?: throw IllegalStateException("SSH session tertutup")
            if (!active.isConnected) throw IllegalStateException("SSH session terputus")
            val channel = active.openChannel("direct-tcpip") as ChannelDirectTCPIP
            channel.setHost(targetHost)
            channel.setPort(targetPort)
            val input = channel.inputStream
            val output = channel.outputStream
            channel.connect(10_000)
            object : UpstreamStream {
                override val input: InputStream = input
                override val output: OutputStream = output
                override fun close() {
                    runCatching { channel.disconnect() }
                }
            }
        }
        socksServer = server
        val port = server.start()
        VpnStateHolder.log(LogLevel.INFO, "SOCKS5 SSH Bridge aktif di 127.0.0.1:$port")
        return port
    }

    override fun close() {
        runCatching { socksServer?.close() }
        runCatching { session?.disconnect() }
        socksServer = null
        session = null
    }
}
