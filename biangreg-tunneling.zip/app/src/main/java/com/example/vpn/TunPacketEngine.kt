package com.example.vpn

import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.example.data.model.LogLevel
import java.io.Closeable
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

class TunPacketEngine(
    private val vpnService: VpnService,
    private val tunFd: ParcelFileDescriptor,
    private val socksPort: Int,
    private val dnsPrimary: String
) : Closeable {

    private val running = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool()
    private val tunIn = FileInputStream(tunFd.fileDescriptor)
    private val tunOut = FileOutputStream(tunFd.fileDescriptor)
    private val writeLock = Any()

    private val tcpSessions = ConcurrentHashMap<FlowKey, TcpFlow>()
    private val udpChannels = ConcurrentHashMap<FlowKey, UdpFlow>()

    val directBytesUp = AtomicLong(0L)
    val directBytesDown = AtomicLong(0L)

    data class FlowKey(
        val srcIp: Int,
        val srcPort: Int,
        val dstIp: Int,
        val dstPort: Int
    )

    inner class UdpFlow(
        val key: FlowKey,
        val channel: DatagramChannel
    ) {
        @Volatile
        var lastActiveMs: Long = System.currentTimeMillis()
    }

    inner class TcpFlow(
        val key: FlowKey,
        var serverSeq: Long,
        var clientNextSeq: Long
    ) {
        @Volatile
        var socket: Socket? = null
        @Volatile
        var closed: Boolean = false
        val outLock = Any()
    }

    fun start() {
        if (running.getAndSet(true)) return
        executor.execute { readTunLoop() }
    }

    private fun readTunLoop() {
        val packet = ByteArray(32767)
        while (running.get()) {
            try {
                val length = tunIn.read(packet)
                if (length < 0) break
                if (length < 20) continue
                val version = (packet[0].toInt() ushr 4) and 0x0F
                if (version != 4) continue

                val ihl = (packet[0].toInt() and 0x0F) * 4
                val totalLen = uint16(packet, 2).coerceAtMost(length)
                if (ihl < 20 || totalLen < ihl) continue

                val protocol = packet[9].toInt() and 0xFF
                val srcIp = int32(packet, 12)
                val dstIp = int32(packet, 16)

                when (protocol) {
                    17 -> handleUdpPacket(packet, ihl, totalLen, srcIp, dstIp)
                    6 -> handleTcpPacket(packet, ihl, totalLen, srcIp, dstIp)
                }
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private fun handleUdpPacket(
        pkt: ByteArray,
        ihl: Int,
        totalLen: Int,
        srcIp: Int,
        dstIp: Int
    ) {
        if (totalLen < ihl + 8) return
        val srcPort = uint16(pkt, ihl)
        val dstPort = uint16(pkt, ihl + 2)
        val payloadOffset = ihl + 8
        val payloadLen = totalLen - payloadOffset
        if (payloadLen <= 0) return

        val payload = pkt.copyOfRange(payloadOffset, totalLen)
        val key = FlowKey(srcIp, srcPort, dstIp, dstPort)
        directBytesUp.addAndGet(payload.size.toLong())

        val flow = udpChannels.computeIfAbsent(key) {
            val ch = DatagramChannel.open()
            vpnService.protect(ch.socket())
            ch.configureBlocking(true)
            val created = UdpFlow(key, ch)
            executor.execute { listenUdpReplies(created) }
            created
        }
        flow.lastActiveMs = System.currentTimeMillis()

        executor.execute {
            try {
                val targetAddr = if (dstPort == 53) {
                    InetAddress.getByName(dnsPrimary)
                } else {
                    intToInetAddress(dstIp)
                }
                flow.channel.send(ByteBuffer.wrap(payload), InetSocketAddress(targetAddr, dstPort))
            } catch (_: Exception) {
                udpChannels.remove(key)
                runCatching { flow.channel.close() }
            }
        }
    }

    private fun listenUdpReplies(flow: UdpFlow) {
        val buf = ByteBuffer.allocate(4096)
        try {
            while (running.get()) {
                buf.clear()
                val sender = flow.channel.receive(buf) ?: break
                val len = buf.position()
                if (len <= 0) continue
                buf.flip()
                val data = ByteArray(len)
                buf.get(data)
                directBytesDown.addAndGet(len.toLong())
                flow.lastActiveMs = System.currentTimeMillis()
                val ipPacket = buildIpv4UdpPacket(
                    srcIp = flow.key.dstIp,
                    dstIp = flow.key.srcIp,
                    srcPort = flow.key.dstPort,
                    dstPort = flow.key.srcPort,
                    payload = data
                )
                writeToTun(ipPacket)
            }
        } catch (_: Exception) {
        } finally {
            udpChannels.remove(flow.key)
            runCatching { flow.channel.close() }
        }
    }

    private fun handleTcpPacket(
        pkt: ByteArray,
        ihl: Int,
        totalLen: Int,
        srcIp: Int,
        dstIp: Int
    ) {
        if (totalLen < ihl + 20) return
        val srcPort = uint16(pkt, ihl)
        val dstPort = uint16(pkt, ihl + 2)
        val seq = uint32(pkt, ihl + 4)
        val dataOffset = ((pkt[ihl + 12].toInt() ushr 4) and 0x0F) * 4
        if (totalLen < ihl + dataOffset) return

        val flags = pkt[ihl + 13].toInt() and 0xFF
        val isSyn = (flags and 0x02) != 0
        val isFin = (flags and 0x01) != 0
        val isRst = (flags and 0x04) != 0

        val payloadOffset = ihl + dataOffset
        val payloadLen = totalLen - payloadOffset
        val key = FlowKey(srcIp, srcPort, dstIp, dstPort)

        if (isRst) {
            tcpSessions.remove(key)?.let { closeTcpFlow(it) }
            return
        }

        if (isSyn) {
            tcpSessions.remove(key)?.let { closeTcpFlow(it) }
            val initialServerSeq = Random.nextLong(1000L, 1_000_000_000L)
            val flow = TcpFlow(
                key = key,
                serverSeq = initialServerSeq,
                clientNextSeq = (seq + 1L) and 0xFFFFFFFFL
            )
            tcpSessions[key] = flow
            executor.execute { connectTcpThroughSocks(flow) }
            return
        }

        val flow = tcpSessions[key] ?: return
        if (flow.closed) return

        if (payloadLen > 0) {
            val payload = pkt.copyOfRange(payloadOffset, totalLen)
            flow.clientNextSeq = (seq + payloadLen.toLong()) and 0xFFFFFFFFL
            val sock = flow.socket
            if (sock != null) {
                executor.execute {
                    try {
                        synchronized(flow.outLock) {
                            sock.getOutputStream().write(payload)
                            sock.getOutputStream().flush()
                        }
                        writeToTun(
                            buildIpv4TcpPacket(
                                srcIp = key.dstIp,
                                dstIp = key.srcIp,
                                srcPort = key.dstPort,
                                dstPort = key.srcPort,
                                seq = flow.serverSeq,
                                ack = flow.clientNextSeq,
                                flags = 0x10 // ACK
                            )
                        )
                    } catch (_: Exception) {
                        sendRstAndClose(flow)
                    }
                }
            }
        }

        if (isFin) {
            flow.clientNextSeq = (flow.clientNextSeq + 1L) and 0xFFFFFFFFL
            writeToTun(
                buildIpv4TcpPacket(
                    srcIp = key.dstIp,
                    dstIp = key.srcIp,
                    srcPort = key.dstPort,
                    dstPort = key.srcPort,
                    seq = flow.serverSeq,
                    ack = flow.clientNextSeq,
                    flags = 0x11 // FIN + ACK
                )
            )
            flow.serverSeq = (flow.serverSeq + 1L) and 0xFFFFFFFFL
            tcpSessions.remove(key)
            closeTcpFlow(flow)
        }
    }

    private fun connectTcpThroughSocks(flow: TcpFlow) {
        try {
            val targetIpStr = intToInetAddress(flow.key.dstIp).hostAddress ?: return
            val sock = Socket("127.0.0.1", socksPort).apply {
                tcpNoDelay = true
                soTimeout = 15_000
            }
            val out = sock.getOutputStream()
            val input = sock.getInputStream()

            // SOCKS5 Greeting
            out.write(byteArrayOf(0x05, 0x01, 0x00))
            out.flush()
            val g0 = input.read()
            val g1 = input.read()
            if (g0 != 0x05 || g1 != 0x00) {
                sock.close()
                sendRstAndClose(flow)
                return
            }

            // SOCKS5 CONNECT IPv4
            val ipBytes = intToIpBytes(flow.key.dstIp)
            out.write(
                byteArrayOf(
                    0x05, 0x01, 0x00, 0x01,
                    ipBytes[0], ipBytes[1], ipBytes[2], ipBytes[3],
                    ((flow.key.dstPort ushr 8) and 0xFF).toByte(),
                    (flow.key.dstPort and 0xFF).toByte()
                )
            )
            out.flush()

            val resp = ByteArray(10)
            var read = 0
            while (read < 10) {
                val r = input.read(resp, read, 10 - read)
                if (r == -1) break
                read += r
            }
            if (read < 4 || resp[1].toInt() != 0x00) {
                VpnStateHolder.log(LogLevel.WARN, "SOCKS5 reject untuk $targetIpStr:${flow.key.dstPort}")
                sock.close()
                sendRstAndClose(flow)
                return
            }

            sock.soTimeout = 0
            flow.socket = sock

            // Send SYN+ACK to TUN
            writeToTun(
                buildIpv4TcpPacket(
                    srcIp = flow.key.dstIp,
                    dstIp = flow.key.srcIp,
                    srcPort = flow.key.dstPort,
                    dstPort = flow.key.srcPort,
                    seq = flow.serverSeq,
                    ack = flow.clientNextSeq,
                    flags = 0x12 // SYN + ACK
                )
            )
            flow.serverSeq = (flow.serverSeq + 1L) and 0xFFFFFFFFL

            // Pump upstream response -> TUN
            val buf = ByteArray(1360)
            while (running.get() && !flow.closed) {
                val n = input.read(buf)
                if (n <= 0) break
                val chunk = buf.copyOf(n)
                writeToTun(
                    buildIpv4TcpPacket(
                        srcIp = flow.key.dstIp,
                        dstIp = flow.key.srcIp,
                        srcPort = flow.key.dstPort,
                        dstPort = flow.key.srcPort,
                        seq = flow.serverSeq,
                        ack = flow.clientNextSeq,
                        flags = 0x18, // PSH + ACK
                        payload = chunk
                    )
                )
                flow.serverSeq = (flow.serverSeq + n.toLong()) and 0xFFFFFFFFL
            }

            if (!flow.closed) {
                writeToTun(
                    buildIpv4TcpPacket(
                        srcIp = flow.key.dstIp,
                        dstIp = flow.key.srcIp,
                        srcPort = flow.key.dstPort,
                        dstPort = flow.key.srcPort,
                        seq = flow.serverSeq,
                        ack = flow.clientNextSeq,
                        flags = 0x11 // FIN + ACK
                    )
                )
                tcpSessions.remove(flow.key)
                closeTcpFlow(flow)
            }
        } catch (_: Exception) {
            sendRstAndClose(flow)
        }
    }

    private fun sendRstAndClose(flow: TcpFlow) {
        if (flow.closed) return
        writeToTun(
            buildIpv4TcpPacket(
                srcIp = flow.key.dstIp,
                dstIp = flow.key.srcIp,
                srcPort = flow.key.dstPort,
                dstPort = flow.key.srcPort,
                seq = flow.serverSeq,
                ack = flow.clientNextSeq,
                flags = 0x14 // RST + ACK
            )
        )
        tcpSessions.remove(flow.key)
        closeTcpFlow(flow)
    }

    private fun closeTcpFlow(flow: TcpFlow) {
        flow.closed = true
        runCatching { flow.socket?.close() }
    }

    private fun writeToTun(packet: ByteArray) {
        synchronized(writeLock) {
            if (!running.get()) return
            runCatching {
                tunOut.write(packet)
            }
        }
    }

    private fun buildIpv4UdpPacket(
        srcIp: Int,
        dstIp: Int,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val totalLen = 20 + 8 + payload.size
        val buf = ByteBuffer.allocate(totalLen)
        // IPv4 header
        buf.put(0x45.toByte())
        buf.put(0x00.toByte())
        buf.putShort(totalLen.toShort())
        buf.putShort(0)
        buf.putShort(0x4000.toShort())
        buf.put(64.toByte())
        buf.put(17.toByte())
        buf.putShort(0)
        buf.putInt(srcIp)
        buf.putInt(dstIp)

        // UDP header
        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putShort((8 + payload.size).toShort())
        buf.putShort(0)
        buf.put(payload)

        val arr = buf.array()
        val ipCsum = computeChecksum(arr, 0, 20)
        arr[10] = ((ipCsum ushr 8) and 0xFF).toByte()
        arr[11] = (ipCsum and 0xFF).toByte()

        val udpCsum = computeTransportChecksum(arr, 20, 8 + payload.size, srcIp, dstIp, 17)
        arr[26] = ((udpCsum ushr 8) and 0xFF).toByte()
        arr[27] = (udpCsum and 0xFF).toByte()
        return arr
    }

    private fun buildIpv4TcpPacket(
        srcIp: Int,
        dstIp: Int,
        srcPort: Int,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        payload: ByteArray = ByteArray(0)
    ): ByteArray {
        val totalLen = 20 + 20 + payload.size
        val buf = ByteBuffer.allocate(totalLen)
        buf.put(0x45.toByte())
        buf.put(0x00.toByte())
        buf.putShort(totalLen.toShort())
        buf.putShort(0)
        buf.putShort(0x4000.toShort())
        buf.put(64.toByte())
        buf.put(6.toByte())
        buf.putShort(0)
        buf.putInt(srcIp)
        buf.putInt(dstIp)

        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putInt(seq.toInt())
        buf.putInt(ack.toInt())
        buf.put(0x50.toByte()) // 20 bytes TCP header
        buf.put(flags.toByte())
        buf.putShort(65535.toShort())
        buf.putShort(0)
        buf.putShort(0)
        buf.put(payload)

        val arr = buf.array()
        val ipCsum = computeChecksum(arr, 0, 20)
        arr[10] = ((ipCsum ushr 8) and 0xFF).toByte()
        arr[11] = (ipCsum and 0xFF).toByte()

        val tcpCsum = computeTransportChecksum(arr, 20, 20 + payload.size, srcIp, dstIp, 6)
        arr[36] = ((tcpCsum ushr 8) and 0xFF).toByte()
        arr[37] = (tcpCsum and 0xFF).toByte()
        return arr
    }

    private fun computeChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < end) {
            sum += (data[i].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFFL) + (sum ushr 16)
        }
        return (sum.inv() and 0xFFFFL).toInt()
    }

    private fun computeTransportChecksum(
        packet: ByteArray,
        offset: Int,
        length: Int,
        srcIp: Int,
        dstIp: Int,
        proto: Int
    ): Int {
        var sum = 0L
        sum += (srcIp ushr 16) and 0xFFFF
        sum += srcIp and 0xFFFF
        sum += (dstIp ushr 16) and 0xFFFF
        sum += dstIp and 0xFFFF
        sum += proto
        sum += length

        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += ((packet[i].toInt() and 0xFF) shl 8) or (packet[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < end) {
            sum += (packet[i].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFFL) + (sum ushr 16)
        }
        val csum = (sum.inv() and 0xFFFFL).toInt()
        return if (proto == 17 && csum == 0) 0xFFFF else csum
    }

    private fun uint16(arr: ByteArray, offset: Int): Int =
        ((arr[offset].toInt() and 0xFF) shl 8) or (arr[offset + 1].toInt() and 0xFF)

    private fun uint32(arr: ByteArray, offset: Int): Long =
        ((arr[offset].toLong() and 0xFF) shl 24) or
            ((arr[offset + 1].toLong() and 0xFF) shl 16) or
            ((arr[offset + 2].toLong() and 0xFF) shl 8) or
            (arr[offset + 3].toLong() and 0xFF)

    private fun int32(arr: ByteArray, offset: Int): Int =
        ((arr[offset].toInt() and 0xFF) shl 24) or
            ((arr[offset + 1].toInt() and 0xFF) shl 16) or
            ((arr[offset + 2].toInt() and 0xFF) shl 8) or
            (arr[offset + 3].toInt() and 0xFF)

    private fun intToIpBytes(ip: Int): ByteArray = byteArrayOf(
        ((ip ushr 24) and 0xFF).toByte(),
        ((ip ushr 16) and 0xFF).toByte(),
        ((ip ushr 8) and 0xFF).toByte(),
        (ip and 0xFF).toByte()
    )

    private fun intToInetAddress(ip: Int): InetAddress =
        InetAddress.getByAddress(intToIpBytes(ip))

    override fun close() {
        running.set(false)
        tcpSessions.values.forEach { closeTcpFlow(it) }
        tcpSessions.clear()
        udpChannels.values.forEach { runCatching { it.channel.close() } }
        udpChannels.clear()
        executor.shutdownNow()
    }
}
