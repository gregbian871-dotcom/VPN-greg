package com.example.vpn

import android.net.VpnService
import android.util.Base64
import com.example.data.model.LogLevel
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.model.V2RaySecurity
import com.example.data.model.V2RayTransport
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.InetAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class V2RayTunnelManager(
    private val vpnService: VpnService,
    private val profile: TunnelProfile
) : Closeable {

    private var socksServer: LocalSocks5Server? = null
    private val wsExecutor = Executors.newCachedThreadPool()

    val localSocksPort: Int
        get() = socksServer?.port ?: -1

    val totalBytesUp: Long
        get() = socksServer?.totalBytesUp?.get() ?: 0L

    val totalBytesDown: Long
        get() = socksServer?.totalBytesDown?.get() ?: 0L

    fun start(): Int {
        val host = profile.v2rayAddress.trim()
        val port = profile.v2rayPort
        val sni = profile.v2raySni.ifBlank { profile.v2rayWsHost.ifBlank { host } }.trim()

        VpnStateHolder.log(
            LogLevel.INFO,
            "Memverifikasi endpoint ${profile.protocol.shortBadge} ke $host:$port (${profile.v2rayTransport.label}/${profile.v2raySecurity.label})..."
        )

        // Initial connectivity & transport verification
        val probeSocket = PayloadSocketFactory.connectProtected(vpnService, host, port, 10_000)
        probeSocket.use { raw ->
            if (profile.v2raySecurity != V2RaySecurity.NONE) {
                val tls = PayloadSocketFactory.wrapProtectedTls(raw, host, port, sni)
                VpnStateHolder.log(
                    LogLevel.NET,
                    "Handshake TLS (${sni.ifBlank { host }}) OK: ${tls.session.protocol} / ${tls.session.cipherSuite}"
                )
            } else {
                VpnStateHolder.log(LogLevel.NET, "Koneksi TCP ke $host:$port berhasil")
            }
        }

        if (profile.protocol == TunnelProtocol.V2RAY_VMESS) {
            VpnStateHolder.log(
                LogLevel.WARN,
                "Mode VMess memakai transport probe; untuk streaming penuh gunakan VLESS, Trojan, Shadowsocks, atau SSH."
            )
        } else if (profile.v2raySecurity == V2RaySecurity.REALITY) {
            VpnStateHolder.log(
                LogLevel.WARN,
                "VLESS Reality memerlukan core XTLS native; menggunakan TLS standar jika server mendukung."
            )
        }

        val server = LocalSocks5Server { targetHost, targetPort ->
            when (profile.protocol) {
                TunnelProtocol.V2RAY_TROJAN -> openTrojanStream(targetHost, targetPort)
                TunnelProtocol.V2RAY_VLESS -> openVlessStream(targetHost, targetPort)
                TunnelProtocol.V2RAY_SHADOWSOCKS -> openShadowsocksStream(targetHost, targetPort)
                TunnelProtocol.V2RAY_VMESS -> openDirectProtectedFallback(targetHost, targetPort)
                else -> openDirectProtectedFallback(targetHost, targetPort)
            }
        }
        socksServer = server
        val localPort = server.start()
        VpnStateHolder.log(
            LogLevel.INFO,
            "SOCKS5 ${profile.protocol.shortBadge} Bridge aktif di 127.0.0.1:$localPort"
        )
        return localPort
    }

    private fun openTrojanStream(targetHost: String, targetPort: Int): UpstreamStream {
        val host = profile.v2rayAddress.trim()
        val port = profile.v2rayPort
        val sni = profile.v2raySni.ifBlank { host }.trim()
        val raw = PayloadSocketFactory.connectProtected(vpnService, host, port, 12_000)
        val socket: Socket = if (profile.v2raySecurity != V2RaySecurity.NONE) {
            PayloadSocketFactory.wrapProtectedTls(raw, host, port, sni)
        } else {
            raw
        }

        val stream = wrapTransportIfWebSocket(socket, host, sni)
        val passHash = sha224Hex(profile.v2rayUuid)
        val addrBytes = encodeSocksTargetAddress(targetHost, targetPort)
        val header = ByteArrayOutputStream().apply {
            write(passHash.toByteArray(Charsets.US_ASCII))
            write('\r'.code)
            write('\n'.code)
            write(0x01) // CMD CONNECT
            write(addrBytes)
            write('\r'.code)
            write('\n'.code)
        }.toByteArray()

        stream.output.write(header)
        stream.output.flush()
        return stream
    }

    private fun openVlessStream(targetHost: String, targetPort: Int): UpstreamStream {
        val host = profile.v2rayAddress.trim()
        val port = profile.v2rayPort
        val sni = profile.v2raySni.ifBlank { profile.v2rayWsHost.ifBlank { host } }.trim()
        val raw = PayloadSocketFactory.connectProtected(vpnService, host, port, 12_000)
        val socket: Socket = if (profile.v2raySecurity != V2RaySecurity.NONE) {
            PayloadSocketFactory.wrapProtectedTls(raw, host, port, sni)
        } else {
            raw
        }

        val stream = wrapTransportIfWebSocket(socket, host, sni)
        val uuid = UUID.fromString(profile.v2rayUuid.trim())
        val uuidBytes = ByteBuffer.allocate(16)
            .putLong(uuid.mostSignificantBits)
            .putLong(uuid.leastSignificantBits)
            .array()

        val targetBytes = encodeVlessAddress(targetHost, targetPort)
        val header = ByteArrayOutputStream().apply {
            write(0x00) // Version 0
            write(uuidBytes)
            write(0x00) // Addons length = 0
            write(0x01) // Command TCP
            write((targetPort ushr 8) and 0xFF)
            write(targetPort and 0xFF)
            write(targetBytes)
        }.toByteArray()

        stream.output.write(header)
        stream.output.flush()

        // VLESS server sends 2-byte response header (version + addons len) before payload
        return object : UpstreamStream {
            private var headerRead = false
            override val input: InputStream = object : InputStream() {
                override fun read(): Int {
                    ensureVlessAck()
                    return stream.input.read()
                }

                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    ensureVlessAck()
                    return stream.input.read(b, off, len)
                }

                private fun ensureVlessAck() {
                    if (!headerRead) {
                        headerRead = true
                        val ver = stream.input.read()
                        if (ver == -1) throw EOFException("VLESS EOF")
                        val addonLen = stream.input.read()
                        if (addonLen > 0) {
                            val skip = ByteArray(addonLen)
                            var r = 0
                            while (r < addonLen) {
                                val n = stream.input.read(skip, r, addonLen - r)
                                if (n == -1) break
                                r += n
                            }
                        }
                    }
                }
            }
            override val output: OutputStream = stream.output
            override fun close() = stream.close()
        }
    }

    private fun openShadowsocksStream(targetHost: String, targetPort: Int): UpstreamStream {
        val host = profile.v2rayAddress.trim()
        val port = profile.v2rayPort
        val method = profile.v2raySecurityMethod.lowercase().ifBlank { "aes-256-gcm" }
        val keySize = if (method.contains("128")) 16 else 32
        val masterKey = evpBytesToKey(profile.v2rayUuid.toByteArray(Charsets.UTF_8), keySize)

        val socket = PayloadSocketFactory.connectProtected(vpnService, host, port, 12_000)
        val rawIn = socket.getInputStream()
        val rawOut = socket.getOutputStream()

        val salt = ByteArray(keySize).also { SecureRandom().nextBytes(it) }
        rawOut.write(salt)
        rawOut.flush()
        val sendSubkey = hkdfSha1(masterKey, salt, "ss-subkey".toByteArray(Charsets.US_ASCII), keySize)

        val targetAddr = encodeSocksTargetAddress(targetHost, targetPort)
        val sendNonce = LongArray(1) { 0L }
        writeSsChunk(rawOut, sendSubkey, sendNonce, targetAddr)

        val pipedIn = PipedInputStream(32768)
        val pipedOut = PipedOutputStream(pipedIn)

        wsExecutor.execute {
            try {
                val recvSalt = readExact(rawIn, keySize)
                val recvSubkey = hkdfSha1(
                    masterKey,
                    recvSalt,
                    "ss-subkey".toByteArray(Charsets.US_ASCII),
                    keySize
                )
                val recvNonce = LongArray(1) { 0L }
                while (true) {
                    val encLen = readExact(rawIn, 2 + 16)
                    val lenBytes = aeadDecrypt(recvSubkey, nextNonce(recvNonce), encLen)
                    val chunkLen = ((lenBytes[0].toInt() and 0xFF) shl 8) or (lenBytes[1].toInt() and 0xFF)
                    val encPayload = readExact(rawIn, chunkLen + 16)
                    val plain = aeadDecrypt(recvSubkey, nextNonce(recvNonce), encPayload)
                    pipedOut.write(plain)
                    pipedOut.flush()
                }
            } catch (_: Exception) {
                runCatching { pipedOut.close() }
            }
        }

        val ssOutput = object : OutputStream() {
            override fun write(b: Int) {
                write(byteArrayOf(b.toByte()), 0, 1)
            }

            override fun write(b: ByteArray, off: Int, len: Int) {
                var offset = off
                var remaining = len
                while (remaining > 0) {
                    val chunkSize = minOf(remaining, 16000)
                    val slice = b.copyOfRange(offset, offset + chunkSize)
                    writeSsChunk(rawOut, sendSubkey, sendNonce, slice)
                    offset += chunkSize
                    remaining -= chunkSize
                }
            }

            override fun flush() = rawOut.flush()
        }

        return object : UpstreamStream {
            override val input: InputStream = pipedIn
            override val output: OutputStream = ssOutput
            override fun close() {
                runCatching { pipedIn.close() }
                runCatching { socket.close() }
            }
        }
    }

    private fun openDirectProtectedFallback(targetHost: String, targetPort: Int): UpstreamStream {
        val socket = PayloadSocketFactory.connectProtected(vpnService, targetHost, targetPort, 10_000)
        return object : UpstreamStream {
            override val input: InputStream = socket.getInputStream()
            override val output: OutputStream = socket.getOutputStream()
            override fun close() = runCatching { socket.close() }.getOrDefault(Unit)
        }
    }

    private fun wrapTransportIfWebSocket(
        socket: Socket,
        host: String,
        sni: String
    ): UpstreamStream {
        if (profile.v2rayTransport != V2RayTransport.WS) {
            return object : UpstreamStream {
                override val input: InputStream = socket.getInputStream()
                override val output: OutputStream = socket.getOutputStream()
                override fun close() = runCatching { socket.close() }.getOrDefault(Unit)
            }
        }

        val wsHost = profile.v2rayWsHost.ifBlank { sni.ifBlank { host } }
        val wsPath = profile.v2rayWsPath.ifBlank { "/" }
        val keyBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val wsKey = Base64.encodeToString(keyBytes, Base64.NO_WRAP)
        val upgrade = buildString {
            append("GET $wsPath HTTP/1.1\r\n")
            append("Host: $wsHost\r\n")
            append("Upgrade: websocket\r\n")
            append("Connection: Upgrade\r\n")
            append("Sec-WebSocket-Key: $wsKey\r\n")
            append("Sec-WebSocket-Version: 13\r\n\r\n")
        }

        val rawOut = socket.getOutputStream()
        val rawIn = socket.getInputStream()
        rawOut.write(upgrade.toByteArray(Charsets.US_ASCII))
        rawOut.flush()

        val headerBuf = ByteArrayOutputStream()
        var last4 = 0
        while (true) {
            val b = rawIn.read()
            if (b == -1) throw IOException("WebSocket EOF saat handshake")
            headerBuf.write(b)
            last4 = (last4 shl 8) or (b and 0xFF)
            if (last4 == 0x0D0A0D0A) break
        }
        val status = headerBuf.toString(Charsets.UTF_8.name()).lineSequence().firstOrNull().orEmpty()
        if (!status.contains("101")) {
            throw IOException("WebSocket upgrade ditolak: $status")
        }

        val pipedIn = PipedInputStream(32768)
        val pipedOut = PipedOutputStream(pipedIn)

        wsExecutor.execute {
            try {
                while (true) {
                    val b1 = rawIn.read()
                    if (b1 == -1) break
                    val b2 = rawIn.read()
                    if (b2 == -1) break
                    val opcode = b1 and 0x0F
                    val masked = (b2 and 0x80) != 0
                    var payloadLen = (b2 and 0x7F).toLong()
                    if (payloadLen == 126L) {
                        val ext = readExact(rawIn, 2)
                        payloadLen = (((ext[0].toInt() and 0xFF) shl 8) or (ext[1].toInt() and 0xFF)).toLong()
                    } else if (payloadLen == 127L) {
                        val ext = readExact(rawIn, 8)
                        payloadLen = ByteBuffer.wrap(ext).long
                    }
                    val maskKey = if (masked) readExact(rawIn, 4) else null
                    val data = readExact(rawIn, payloadLen.toInt())
                    if (maskKey != null) {
                        for (i in data.indices) data[i] = (data[i].toInt() xor maskKey[i % 4].toInt()).toByte()
                    }
                    if (opcode == 0x08) break // Close frame
                    if (opcode == 0x09) {
                        // Ping -> Pong
                        sendWsFrame(rawOut, 0x0A, data)
                        continue
                    }
                    if (opcode == 0x01 || opcode == 0x02 || opcode == 0x00) {
                        pipedOut.write(data)
                        pipedOut.flush()
                    }
                }
            } catch (_: Exception) {
            } finally {
                runCatching { pipedOut.close() }
            }
        }

        val wsOutput = object : OutputStream() {
            override fun write(b: Int) {
                write(byteArrayOf(b.toByte()), 0, 1)
            }

            override fun write(b: ByteArray, off: Int, len: Int) {
                sendWsFrame(rawOut, 0x02, b.copyOfRange(off, off + len))
            }

            override fun flush() = rawOut.flush()
        }

        return object : UpstreamStream {
            override val input: InputStream = pipedIn
            override val output: OutputStream = wsOutput
            override fun close() {
                runCatching { pipedIn.close() }
                runCatching { socket.close() }
            }
        }
    }

    @Synchronized
    private fun sendWsFrame(out: OutputStream, opcode: Int, payload: ByteArray) {
        val frame = ByteArrayOutputStream()
        frame.write(0x80 or (opcode and 0x0F))
        val len = payload.size
        when {
            len <= 125 -> frame.write(0x80 or len)
            len <= 65535 -> {
                frame.write(0x80 or 126)
                frame.write((len ushr 8) and 0xFF)
                frame.write(len and 0xFF)
            }
            else -> {
                frame.write(0x80 or 127)
                frame.write(ByteBuffer.allocate(8).putLong(len.toLong()).array())
            }
        }
        val mask = ByteArray(4).also { SecureRandom().nextBytes(it) }
        frame.write(mask)
        val maskedPayload = ByteArray(len)
        for (i in 0 until len) {
            maskedPayload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
        }
        frame.write(maskedPayload)
        out.write(frame.toByteArray())
        out.flush()
    }

    private fun encodeSocksTargetAddress(host: String, port: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val ipBytes = runCatching {
            val parts = host.split(".")
            if (parts.size == 4 && parts.all { it.toIntOrNull() in 0..255 }) {
                InetAddress.getByName(host).address
            } else null
        }.getOrNull()

        if (ipBytes != null && ipBytes.size == 4) {
            out.write(0x01)
            out.write(ipBytes)
        } else {
            val dom = host.toByteArray(Charsets.UTF_8)
            out.write(0x03)
            out.write(dom.size)
            out.write(dom)
        }
        out.write((port ushr 8) and 0xFF)
        out.write(port and 0xFF)
        return out.toByteArray()
    }

    private fun encodeVlessAddress(host: String, port: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val parts = host.split(".")
        if (parts.size == 4 && parts.all { it.toIntOrNull() in 0..255 }) {
            out.write(0x01)
            parts.forEach { out.write(it.toInt()) }
        } else {
            val dom = host.toByteArray(Charsets.UTF_8)
            out.write(0x02) // VLESS domain ATYP is 0x02
            out.write(dom.size)
            out.write(dom)
        }
        return out.toByteArray()
    }

    private fun sha224Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-224").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun evpBytesToKey(password: ByteArray, keyLen: Int): ByteArray {
        val md5 = MessageDigest.getInstance("MD5")
        val result = ByteArrayOutputStream()
        var prev: ByteArray? = null
        while (result.size() < keyLen) {
            md5.reset()
            if (prev != null) md5.update(prev)
            md5.update(password)
            prev = md5.digest()
            result.write(prev)
        }
        return result.toByteArray().copyOf(keyLen)
    }

    private fun hkdfSha1(ikm: ByteArray, salt: ByteArray, info: ByteArray, len: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(salt, "HmacSHA1"))
        val prk = mac.doFinal(ikm)
        mac.init(SecretKeySpec(prk, "HmacSHA1"))
        val okm = ByteArrayOutputStream()
        var t = ByteArray(0)
        var counter = 1
        while (okm.size() < len) {
            mac.reset()
            mac.update(t)
            mac.update(info)
            mac.update(counter.toByte())
            t = mac.doFinal()
            okm.write(t)
            counter++
        }
        return okm.toByteArray().copyOf(len)
    }

    @Synchronized
    private fun writeSsChunk(out: OutputStream, subkey: ByteArray, nonceRef: LongArray, plain: ByteArray) {
        val lenBytes = byteArrayOf(((plain.size ushr 8) and 0xFF).toByte(), (plain.size and 0xFF).toByte())
        val encLen = aeadEncrypt(subkey, nextNonce(nonceRef), lenBytes)
        val encPayload = aeadEncrypt(subkey, nextNonce(nonceRef), plain)
        out.write(encLen)
        out.write(encPayload)
        out.flush()
    }

    private fun nextNonce(nonceRef: LongArray): ByteArray {
        val v = nonceRef[0]++
        val nonce = ByteArray(12)
        for (i in 0 until 8) {
            nonce[i] = ((v ushr (i * 8)) and 0xFFL).toByte()
        }
        return nonce
    }

    private fun aeadEncrypt(key: ByteArray, nonce: ByteArray, plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        return cipher.doFinal(plain)
    }

    private fun aeadDecrypt(key: ByteArray, nonce: ByteArray, cipherText: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        return cipher.doFinal(cipherText)
    }

    private fun readExact(input: InputStream, len: Int): ByteArray {
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val r = input.read(buf, off, len - off)
            if (r == -1) throw EOFException("Unexpected EOF")
            off += r
        }
        return buf
    }

    override fun close() {
        runCatching { socksServer?.close() }
        socksServer = null
        wsExecutor.shutdownNow()
    }
}
