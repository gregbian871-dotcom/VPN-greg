package com.example.vpn

import com.example.data.model.LogLevel
import com.example.data.model.TunnelLogEntry
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelTelemetry
import com.example.data.model.VpnConnectionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong

object VpnStateHolder {

    private val logIdCounter = AtomicLong(1L)
    private const val MAX_LOGS = 500
    private const val MAX_SPARKLINE_POINTS = 24

    private val _telemetry = MutableStateFlow(TunnelTelemetry())
    val telemetry: StateFlow<TunnelTelemetry> = _telemetry.asStateFlow()

    private val _logs = MutableStateFlow<List<TunnelLogEntry>>(
        listOf(
            TunnelLogEntry(
                id = 0L,
                timestamp = System.currentTimeMillis(),
                level = LogLevel.INFO,
                message = "BianGreg Tunneling Engine siap. Pilih atau buat config SSH/V2Ray."
            )
        )
    )
    val logs: StateFlow<List<TunnelLogEntry>> = _logs.asStateFlow()

    fun log(level: LogLevel, message: String) {
        val entry = TunnelLogEntry(
            id = logIdCounter.getAndIncrement(),
            timestamp = System.currentTimeMillis(),
            level = level,
            message = message
        )
        _logs.update { current ->
            val updated = current + entry
            if (updated.size > MAX_LOGS) updated.takeLast(MAX_LOGS) else updated
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
        log(LogLevel.INFO, "Log terminal dibersihkan.")
    }

    fun setConnecting(profile: TunnelProfile) {
        _telemetry.update {
            TunnelTelemetry(
                status = VpnConnectionState.CONNECTING,
                activeProfileId = profile.id,
                activeProfileName = profile.name,
                activeProtocol = profile.protocol,
                connectedSinceMs = null,
                errorMessage = null
            )
        }
    }

    fun setConnected(profile: TunnelProfile, latencyMs: Long?) {
        _telemetry.update {
            it.copy(
                status = VpnConnectionState.CONNECTED,
                activeProfileId = profile.id,
                activeProfileName = profile.name,
                activeProtocol = profile.protocol,
                connectedSinceMs = System.currentTimeMillis(),
                lastLatencyMs = latencyMs ?: it.lastLatencyMs,
                errorMessage = null
            )
        }
    }

    fun setDisconnecting() {
        _telemetry.update {
            it.copy(status = VpnConnectionState.DISCONNECTING)
        }
    }

    fun setDisconnected(error: String? = null) {
        _telemetry.update {
            TunnelTelemetry(
                status = if (error != null) VpnConnectionState.ERROR else VpnConnectionState.DISCONNECTED,
                activeProfileId = it.activeProfileId,
                activeProfileName = it.activeProfileName,
                activeProtocol = it.activeProtocol,
                connectedSinceMs = null,
                bytesUp = it.bytesUp,
                bytesDown = it.bytesDown,
                speedUpBps = 0L,
                speedDownBps = 0L,
                lastLatencyMs = it.lastLatencyMs,
                errorMessage = error
            )
        }
    }

    fun updateTrafficSample(
        totalUp: Long,
        totalDown: Long,
        speedUpBps: Long,
        speedDownBps: Long
    ) {
        _telemetry.update { current ->
            val nextUpHistory = (current.speedHistoryUp + speedUpBps).takeLast(MAX_SPARKLINE_POINTS)
            val nextDownHistory = (current.speedHistoryDown + speedDownBps).takeLast(MAX_SPARKLINE_POINTS)
            current.copy(
                bytesUp = totalUp,
                bytesDown = totalDown,
                speedUpBps = speedUpBps,
                speedDownBps = speedDownBps,
                speedHistoryUp = nextUpHistory,
                speedHistoryDown = nextDownHistory
            )
        }
    }

    fun updateLatency(latencyMs: Long?) {
        _telemetry.update { it.copy(lastLatencyMs = latencyMs) }
    }
}
