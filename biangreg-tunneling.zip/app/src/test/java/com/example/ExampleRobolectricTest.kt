package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.codec.ConfigCodec
import com.example.data.codec.PayloadGenerator
import com.example.data.codec.PayloadGeneratorOptions
import com.example.data.codec.PayloadInjectMode
import com.example.data.codec.PayloadSplitMode
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.model.V2RaySecurity
import com.example.data.model.V2RayTransport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app_name is BianGreg Tunneling`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("BianGreg Tunneling", appName)
    }

    @Test
    fun `bgt locked bundle export and import roundtrip preserves profiles`() {
        val sshProfile = TunnelProfile(
            name = "SG SSH WS",
            protocol = TunnelProtocol.SSH_WEBSOCKET,
            sshHost = "sg1.example.net",
            sshPort = 443,
            sshUsername = "user1",
            sshPassword = "secret",
            sniHost = "cdn.example.com",
            payload = "GET / [protocol][crlf]Host: cdn.example.com[crlf]Upgrade: websocket[crlf][crlf]"
        )
        val exported = ConfigCodec.exportBundle(listOf(sshProfile), lockCredentials = true)
        assertTrue(exported.startsWith("BGT1:"))

        val imported = ConfigCodec.importAny(exported)
        assertEquals(1, imported.profiles.size)
        val restored = imported.profiles.first()
        assertEquals("SG SSH WS", restored.name)
        assertEquals(TunnelProtocol.SSH_WEBSOCKET, restored.protocol)
        assertEquals("sg1.example.net", restored.sshHost)
        assertTrue(restored.isLocked)
    }

    @Test
    fun `v2ray share uri export and import roundtrip works for vless vmess trojan and ss`() {
        val vless = TunnelProfile(
            name = "VLESS WS",
            protocol = TunnelProtocol.V2RAY_VLESS,
            v2rayAddress = "vless.example.com",
            v2rayPort = 443,
            v2rayUuid = "11111111-2222-3333-4444-555555555555",
            v2rayTransport = V2RayTransport.WS,
            v2raySecurity = V2RaySecurity.TLS,
            v2raySni = "sni.example.com",
            v2rayWsHost = "ws.example.com",
            v2rayWsPath = "/vless"
        )
        val vlessUri = ConfigCodec.exportShareUri(vless)
        val parsedVless = ConfigCodec.importAny(vlessUri).profiles.single()
        assertEquals(TunnelProtocol.V2RAY_VLESS, parsedVless.protocol)
        assertEquals("vless.example.com", parsedVless.v2rayAddress)
        assertEquals("/vless", parsedVless.v2rayWsPath)

        val vmess = vless.copy(name = "VMess WS", protocol = TunnelProtocol.V2RAY_VMESS)
        val parsedVmess = ConfigCodec.importAny(ConfigCodec.exportShareUri(vmess)).profiles.single()
        assertEquals(TunnelProtocol.V2RAY_VMESS, parsedVmess.protocol)
        assertEquals("11111111-2222-3333-4444-555555555555", parsedVmess.v2rayUuid)

        val trojan = vless.copy(name = "Trojan", protocol = TunnelProtocol.V2RAY_TROJAN, v2rayUuid = "trojanpass")
        val parsedTrojan = ConfigCodec.importAny(ConfigCodec.exportShareUri(trojan)).profiles.single()
        assertEquals(TunnelProtocol.V2RAY_TROJAN, parsedTrojan.protocol)
        assertEquals("trojanpass", parsedTrojan.v2rayUuid)

        val ss = TunnelProfile(
            name = "SS AEAD",
            protocol = TunnelProtocol.V2RAY_SHADOWSOCKS,
            v2rayAddress = "ss.example.com",
            v2rayPort = 8388,
            v2rayUuid = "sspass",
            v2raySecurityMethod = "aes-256-gcm"
        )
        val parsedSs = ConfigCodec.importAny(ConfigCodec.exportShareUri(ss)).profiles.single()
        assertEquals(TunnelProtocol.V2RAY_SHADOWSOCKS, parsedSs.protocol)
        assertEquals("aes-256-gcm", parsedSs.v2raySecurityMethod)
        assertEquals("sspass", parsedSs.v2rayUuid)
    }

    @Test
    fun `payload generator expands tags and splits chunks`() {
        val template = PayloadGenerator.generate(
            PayloadGeneratorOptions(
                bugHost = "bug.cdn.test",
                method = "GET",
                injectMode = PayloadInjectMode.FRONT_INJECT,
                splitMode = PayloadSplitMode.DELAY_SPLIT
            )
        )
        assertTrue(template.contains("[delay_split]"))
        val chunks = PayloadGenerator.buildWireChunks(template, "ssh.server.test", 22)
        assertEquals(2, chunks.size)
        assertEquals(0L, chunks[0].delayBeforeMs)
        assertEquals(250L, chunks[1].delayBeforeMs)
        val secondText = String(chunks[1].bytes, Charsets.UTF_8)
        assertTrue(secondText.contains("CONNECT ssh.server.test:22 HTTP/1.1\r\n\r\n"))
    }
}
